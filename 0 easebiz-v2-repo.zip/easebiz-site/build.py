#!/usr/bin/env python3
"""EaseBiz v2 static site builder. Pure Python standard library (works on Cloudflare Pages).

  python3 build.py            -> production build into ./public
  python3 build.py staging    -> test build (noindex, images from www.ease.biz) into ./public

Content you will edit most lives in ./content (JSON + Markdown). Page layouts live in this file.
"""
import html, json, os, re, shutil, sys, datetime
from icons import icon

ROOT = os.path.dirname(os.path.abspath(__file__))
C = lambda f: json.load(open(os.path.join(ROOT, "content", f), encoding="utf-8"))
S = C("settings.json"); TEAM = C("team.json"); QUOTES = C("testimonials.json"); CASES = C("cases.json")
ENV = (sys.argv[1] if len(sys.argv) > 1 else os.environ.get("EB_ENV", "prod"))
STAGING = ENV == "staging"
IMG = "https://www.ease.biz/" if STAGING else "/"
SITE = S["site_url"]
TODAY = datetime.date.today().isoformat()
PAGES = []   # (path, html)
SITEMAP = []


def esc(t): return html.escape(str(t), quote=True)
def plain(t): return re.sub(r"<[^>]+>", "", t).replace("&amp;", "&")
def initials(n): p = n.replace("CA ", "").split(); return (p[0][0] + p[-1][0]).upper()
def ld(*objs): return "".join('<script type="application/ld+json">' + json.dumps(o, ensure_ascii=False, separators=(",", ":")) + "</script>\n" for o in objs if o)


ORG_ID = SITE + "/#org"
ORG = {"@context": "https://schema.org", "@type": ["ProfessionalService", "EmploymentAgency"], "@id": ORG_ID,
       "name": S["legal_name"], "alternateName": "EaseBiz", "url": SITE + "/", "logo": SITE + "/images/logo-black.png",
       "description": "Partner-led leadership hiring and HR advisory firm for founder-led and growing businesses in India. Headquartered in Ahmedabad.",
       "telephone": S["phone_tel"], "email": S["email"],
       "address": {"@type": "PostalAddress", "streetAddress": "A/811, Safal Pegasus, Opp. Venus Atlantis, Prahladnagar Road",
                   "addressLocality": "Ahmedabad", "addressRegion": "Gujarat", "postalCode": "380015", "addressCountry": "IN"},
       "openingHoursSpecification": [{"@type": "OpeningHoursSpecification", "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], "opens": "10:00", "closes": "19:00"}],
       "areaServed": {"@type": "Country", "name": "India"}, "sameAs": [S["linkedin"], S["instagram"]],
       "founder": {"@type": "Person", "name": "Ashish Doshi"}}


def crumbs_ld(trail):
    items = [{"@type": "ListItem", "position": i + 1, "name": n, "item": SITE + p} for i, (n, p) in enumerate([("Home", "/")] + trail)]
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": items}


def faq_ld(faqs):
    return {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": plain(q), "acceptedAnswer": {"@type": "Answer", "text": plain(a)}} for q, a in faqs]}


def service_ld(name, desc, path):
    return {"@context": "https://schema.org", "@type": "Service", "name": name, "description": desc, "provider": {"@id": ORG_ID},
            "areaServed": {"@type": "Country", "name": "India"}, "url": SITE + path}


# ============================================================ layout
NAV = [("Leadership Hiring", "/leadership-hiring/"), ("HR Advisory", "/hr-advisory/"), ("Results", "/results/"),
       ("How We Work", "/how-we-work/"), ("Insights", "/insights/"), ("About", "/about/"), ("Contact", "/contact/")]
BOOK = '/contact/#call'


def head(title, desc, path, schema="", forms=False, og_type="website"):
    canon = SITE + path
    robots = "noindex, nofollow" if STAGING else "index, follow, max-image-preview:large"
    eb = json.dumps({"ga4": S["ga4_id"], "clarity": S["clarity_id"], "booking": S["booking_url"], "tel": S["phone_tel"], "phone": S["phone"]})
    ts = '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>\n' if forms else ""
    return f"""<!doctype html>
<html lang="en-IN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{title}</title>
<meta name="description" content="{esc(desc)}">
<meta name="robots" content="{robots}">
<link rel="canonical" href="{canon}">
<meta property="og:type" content="{og_type}"><meta property="og:site_name" content="EaseBiz"><meta property="og:locale" content="en_IN">
<meta property="og:title" content="{title}"><meta property="og:description" content="{esc(desc)}"><meta property="og:url" content="{canon}">
<meta property="og:image" content="{SITE}/images/og-image.jpg"><meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#10132e">
<link rel="icon" href="{IMG}images/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;1,6..72,500&family=Public+Sans:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/css/site.css?v=2">
<script>window.EB={eb};</script>
{ts}{schema}</head>
<body>
"""


def header(path):
    cur = ' aria-current="page"'
    items = "".join(f'<li><a href="{h}"{cur if path.startswith(h) else ""}>{n}</a></li>' for n, h in NAV)
    bar = '<div class="test-bar">TEST SITE: not the live EaseBiz website.</div>\n' if STAGING else ""
    return f"""{bar}<a class="sr" href="#main">Skip to content</a>
<header class="top"><div class="wrap nav">
  <a class="logo" href="/" aria-label="EaseBiz home"><img src="{IMG}images/logo-black.png" alt="EaseBiz" width="146" height="38"><span class="wm" hidden>ease<b>biz</b></span></a>
  <nav aria-label="Main"><ul class="menu">{items}<li><a href="{S['jobs_url']}" data-track="jobs_click">Jobs ↗</a></li></ul></nav>
  <div class="nav-cta"><a class="btn btn-primary" href="{BOOK}" data-book data-track="book_call_click" data-loc="header">Book a call</a></div>
  <button class="burger" type="button" aria-label="Menu" aria-expanded="false">{icon('menu')}</button>
</div></header>
<main id="main">
"""


def footer():
    return f"""</main>
<footer class="foot"><div class="wrap">
  <div class="fgrid">
    <div><a class="logo" href="/" aria-label="EaseBiz home"><img src="{IMG}images/logo.png" alt="EaseBiz" width="146" height="38"><span class="wm" hidden>ease<b>biz</b></span></a>
      <p style="margin-top:18px;max-width:34ch">Partner-led leadership hiring and HR advisory for founder-led and growing businesses. Ahmedabad, since 2002.</p>
      <p><a href="{S['linkedin']}" rel="noopener" target="_blank">LinkedIn</a> · <a href="{S['instagram']}" rel="noopener" target="_blank">Instagram</a></p></div>
    <div><h4>What we do</h4><ul>
      <li><a href="/leadership-hiring/">Leadership hiring</a></li><li><a href="/hr-advisory/">HR advisory</a></li>
      <li><a href="/scale-up-hiring/">Scale-up &amp; plant hiring</a></li><li><a href="/how-we-work/#fees">How we charge</a></li>
      <li><a href="/hr-health-check/">Free HR health check</a></li></ul></div>
    <div><h4>Company</h4><ul>
      <li><a href="/about/">About &amp; partners</a></li><li><a href="/results/">Results</a></li><li><a href="/insights/">Insights</a></li>
      <li><a href="/gujarat/">Gujarat</a> · <a href="/pan-india/">Pan-India</a></li><li><a href="/careers/">Careers at EaseBiz</a></li>
      <li><a href="{S['jobs_url']}">Job openings ↗</a></li></ul></div>
    <div><h4>Talk to us</h4><ul>
      <li><a href="tel:{S['phone_tel']}">{S['phone']}</a></li><li><a href="mailto:{S['email']}">{S['email']}</a></li>
      <li><a href="https://wa.me/{S['whatsapp']}" rel="noopener" target="_blank">WhatsApp us</a></li>
      <li>{S['address']}</li><li>{S['hours']}</li></ul></div>
  </div>
  <div class="fbot"><span>© <span data-year>2026</span> {S['legal_name']}</span><span><a href="/privacy/">Privacy</a></span></div>
</div></footer>
<a class="wa" href="https://wa.me/{S['whatsapp']}?text=Hi%20EaseBiz%2C%20I%27d%20like%20to%20discuss%20a%20hiring%20requirement." target="_blank" rel="noopener" aria-label="Chat on WhatsApp">{icon('whatsapp')}</a>
<script src="/js/site.js?v=2" defer></script>
</body>
</html>
"""


def phero(trail, title, lead, kicker=""):
    cr = '<nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a>' + "".join(
        f' / <a href="{p}">{n}</a>' if i < len(trail) - 1 else f" / <span>{n}</span>" for i, (n, p) in enumerate(trail)) + "</nav>"
    k = f'<span class="kicker">{kicker}</span>' if kicker else ""
    return f'<section class="phero"><div class="wrap">{cr}{k}<h1>{title}</h1><p class="lead mb0">{lead}</p></div></section>\n'


def faq(faqs, title="Questions we're often asked"):
    items = "".join(f'<details><summary>{q}</summary><div class="a"><p>{a}</p></div></details>' for q, a in faqs)
    return f'<section class="sec"><div class="wrap split"><div><span class="kicker">FAQ</span><h2>{title}</h2></div><div class="faq">{items}</div></div></section>\n'


def ladder(title="Three easy ways to start"):
    return f"""<section class="sec ink"><div class="wrap">
  <div class="head"><span class="kicker">Talk to a partner</span><h2>{title}</h2><p class="lead">No sales team. You'll speak with one of the four partners.</p></div>
  <div class="ladder">
    <div class="rung"><h3>Book a 20-minute call</h3><p>Pick a slot that suits you. We'll listen first, then tell you honestly how we'd approach it.</p><a class="btn btn-light" href="{BOOK}" data-book data-track="book_call_click" data-loc="ladder">Book a call</a></div>
    <div class="rung"><h3>Get a call back</h3><p>Leave your number and a partner will call you within one business day.</p><a class="btn btn-ghost" href="/contact/#callback" data-track="callback_click">Request a call back</a></div>
    <div class="rung"><h3>WhatsApp us</h3><p>Quick question? Message us on {S['phone']} and we'll reply during business hours.</p><a class="btn btn-wa" href="https://wa.me/{S['whatsapp']}" target="_blank" rel="noopener">{icon('whatsapp')} WhatsApp</a></div>
  </div>
</div></section>
"""


def ts_widget():
    return f'<div class="cf-turnstile" data-sitekey="{S["turnstile_sitekey"]}" data-size="flexible"></div>'


def face(m, cap=True):
    c = f'<div class="cap"><b>{m["name"]}</b><span>{m["focus"]}</span></div>' if cap else ""
    return f'<div class="face"><img src="{IMG}{m["photo"]}" alt="{m["name"]}, {m["role"]}, EaseBiz" data-initials="{initials(m["name"])}" loading="lazy">{c}</div>'


def case_card(c):
    return f"""<a class="card case rv" href="/results/#{c['id']}"><div class="tag"><span class="pill">{c['tag']}</span><span class="pill g">{c['weeks']} weeks</span></div>
<h3>{c['headline']}</h3><p class="small muted">{c['client'] or c['sector']}</p><div class="res"><b>{c['metric']}</b>: {c['result']}</div></a>"""


def quote_block(q, dark=False):
    who = ", ".join(x for x in [f"<b>{q['name']}</b>", q["title"], q["company"]] if x)
    return f'<figure class="mb0"><blockquote class="quote">“{q["quote"]}”</blockquote><figcaption class="who">{who}{" · " + q["source"] if q.get("source") else ""}</figcaption></figure>'


def page(path, title, desc, body, trail=None, schema=(), forms=False, og_type="website", in_sitemap=True):
    sch = ld(*(([crumbs_ld(trail)] if trail else []) + list(schema)))
    PAGES.append((path, head(title, desc, path, sch, forms, og_type) + header(path) + body + footer()))
    if in_sitemap:
        SITEMAP.append(path)


# ============================================================ content blocks
SITUATIONS = [
    ("“We need our first professional CEO, COO or CFO, and it has to work.”", "Leadership hiring for founder-led businesses, with the role defined before the search starts.", "/leadership-hiring/", "Leadership hiring"),
    ("“Everything still runs through the MD. We've outgrown our structure.”", "Organisation design, KRAs and HR systems that let leaders actually lead.", "/hr-advisory/", "HR advisory"),
    ("“We're opening a new plant or unit and need a team, fast.”", "Phased hiring, from plant head to shop floor, timed to your launch date.", "/scale-up-hiring/", "Scale-up hiring"),
]
STEPS = [("Listen", "A partner meets the founder and key stakeholders to understand the business, not just the role."),
         ("Define", "We agree the role's authority, 12-month success measures and compensation, in writing."),
         ("Search", "Confidential market mapping and direct approaches. First profiles within 2 working days."),
         ("Land", "Offer support, onboarding guidance and check-ins through the first months.")]
HOME_FAQ = [
    ("What kind of companies do you work with?", "Mostly founder-led and family-owned businesses, usually manufacturing, pharma, engineering, services and consumer companies, that are growing and need professional leadership or better people systems."),
    ("Who will actually work on our mandate?", "One of our four partners leads every engagement personally, from the first conversation to post-joining check-ins."),
    ("How fast will we see candidates?", "First relevant profiles within 2 working days of the briefing. Senior searches take longer overall because of assessment and notice periods; we agree a timeline at the start."),
    ("How do you charge?", "Retained fees for CXO searches, success fees for other leadership hires and a monthly retainer for HR advisory. You get a written proposal within 24 hours of the briefing. <a href=\"/how-we-work/#fees\">See how we charge</a>."),
    ("Do you work outside Gujarat?", "Yes. We're based in Ahmedabad and work with companies across India, mapping candidates nationally."),
]


# ============================================================ pages
def build_home():
    faces = "".join(face(m) for m in TEAM)
    sits = "".join(f'<div class="sit rv"><p class="q">{q}</p><p>{d}</p><a class="more" href="{h}">{l} {icon("arrow")}</a></div>' for q, d, h, l in SITUATIONS)
    steps = "".join(f'<div class="step rv"><b>{i+1}. {t}</b><p>{d}</p></div>' for i, (t, d) in enumerate(STEPS))
    feat = CASES[1]
    q = QUOTES[0]
    team_list = "".join(f'<li><b style="color:var(--ink)">{m["name"]}</b>: {m["leads"]}</li>' for m in TEAM)
    body = f"""
<section class="hero"><div class="wrap">
  <div>
    <span class="kicker">Leadership hiring · HR advisory</span>
    <h1>Hire the leaders your <em>next stage</em> needs.</h1>
    <p class="lead">EaseBiz helps founder-led and growing businesses hire professional leaders and build the structure around them. A partner runs every engagement, start to finish.</p>
    <div class="row-btns"><a class="btn btn-primary" href="{BOOK}" data-book data-track="book_call_click" data-loc="hero">Book a 20-minute call {icon('arrow')}</a>
      <a class="btn btn-line" href="/contact/#brief" data-track="brief_click">Share a role</a></div>
    <div class="trust"><span><b>{S['stats']['clients']}</b> clients</span><span><b>{S['stats']['retention']}</b> come back</span><span>Partner-led <b>since {S['stats']['since']}</b></span><span>Based in <b>Ahmedabad</b></span></div>
  </div>
  <div class="faces">{faces}<p class="faces-note">You'll work with one of these four partners, not a junior recruiter.</p></div>
</div></section>

<section class="sec"><div class="wrap">
  <div class="head"><span class="kicker">Who we help</span><h2>Businesses at the point where the founder can't do it all</h2></div>
  <div class="grid g3">{sits}</div>
</div></section>

<section class="sec alt"><div class="wrap split mid">
  <div class="rv"><span class="kicker">Proof</span><div class="metric">{feat['metric']}</div>
    <h2 style="font-size:clamp(1.5rem,2.6vw,2rem)">{feat['headline']}</h2>
    <p>{feat['problem']} {feat['result']}</p><a class="more" href="/results/#{feat['id']}">Read the case {icon('arrow')}</a></div>
  <div class="card rv">{quote_block(q)}</div>
</div>
<div class="wrap mt"><div class="grid g3">{''.join(case_card(c) for c in [CASES[0], CASES[2], CASES[3]])}</div>
<p class="mt center"><a class="btn btn-line" href="/results/">All results</a></p></div></section>

<section class="sec ink"><div class="wrap">
  <div class="head"><span class="kicker">How we work</span><h2>Structure first, then the right person</h2>
  <p class="lead">Most failed senior hires fail because the role was unclear, not because the person was weak. We fix that before we search.</p></div>
  <div class="steps">{steps}</div>
  <p class="mt"><a class="btn btn-ghost" href="/how-we-work/">How we work &amp; how we charge</a></p>
</div></section>

<section class="sec"><div class="wrap split mid">
  <div class="rv"><span class="kicker">The partners</span><h2>Four partners. Every mandate personally led.</h2>
    <p>Our partners bring backgrounds in strategic HR, talent acquisition, operations and chartered accountancy, so we understand the business behind the role.</p>
    <ul class="checks">{team_list}</ul><a class="more" href="/about/#partners">Meet the partners {icon('arrow')}</a></div>
  <div class="card rv" style="background:var(--bg-2);border:0"><span class="kicker">Free resource</span><h3 style="font-family:var(--f-display);font-weight:500;font-size:1.6rem">The CXO Hiring Checklist for founder-led businesses</h3>
    <p>12 decisions to make before you start a senior search. Takes 10 minutes; can save you a failed hire.</p>
    <a class="btn btn-primary" href="/resources/cxo-hiring-checklist/" data-track="checklist_click">Get the checklist</a></div>
</div></section>
{faq(HOME_FAQ)}
{ladder()}"""
    page("/", "EaseBiz | Leadership Hiring &amp; HR Advisory, Ahmedabad",
         "Partner-led leadership hiring and HR advisory for founder-led and growing businesses in India. Ahmedabad-based. First profiles in 2 working days.",
         body, schema=[ORG, {"@context": "https://schema.org", "@type": "WebSite", "url": SITE + "/", "name": "EaseBiz", "publisher": {"@id": ORG_ID}}, faq_ld(HOME_FAQ)])


def build_leadership():
    levels = [("CXO &amp; business heads", "CEO, MD, COO, CFO, CHRO, CTO, business and country heads", "Retained search"),
              ("Function &amp; senior leaders", "VPs, directors, plant heads, heads of sales, finance, HR, supply chain", "Success fee"),
              ("Specialists &amp; confidential roles", "Niche technical leaders and confidential replacements via direct headhunting", "Success fee")]
    rows = "".join(f"<tr><th scope=row>{a}</th><td>{b}</td><td>{c}</td></tr>" for a, b, c in levels)
    approaches = [("search", "Executive search", "Research-led, confidential search for CXO and business-head roles: market mapping, direct approaches, structured assessment and onboarding support."),
                  ("headhunting", "Headhunting", "Discreet, direct outreach to proven performers at competitor and adjacent companies, for niche or confidential roles that job portals can't fill."),
                  ("lateral", "Leadership &amp; lateral hiring", "VPs, directors and function heads hired with the same rigour as a CXO search, so the layer that executes strategy is as strong as the top.")]
    ap = "".join(f'<div class="card rv" id="{i}"><h3>{t}</h3><p>{d}</p></div>' for i, t, d in approaches)
    sectors = ["Manufacturing &amp; engineering", "Pharma &amp; life sciences", "Chemicals", "Auto components", "Infrastructure &amp; energy", "Financial services", "Technology &amp; services", "Consumer &amp; retail"]
    cases = [c for c in CASES if c["service"] == "leadership-hiring"]
    fq = [("How long does a senior search take?", "First profiles reach you within 2 working days of the briefing. A CXO search typically runs a few weeks to a couple of months before an offer, plus the candidate's notice period."),
          ("Can you run a confidential search?", "Yes. Confidential replacements are common for us. Roles aren't advertised and candidates learn the company name only when appropriate."),
          ("What happens after the candidate joins?", "We stay in touch with both sides through the first months, with onboarding guidance and check-ins."),
          ("Why do first professional hires fail in family businesses?", "Usually because authority and success measures were never agreed. We define both with you before the search starts. <a href=\"/insights/hiring-first-professional-cxo/\">Read our guide</a>.")]
    body = f"""{phero([("Leadership Hiring", "/leadership-hiring/")], "Leadership hiring for founder-led and growing businesses.", "CXOs, function heads and specialists, found through a partner-led, confidential search that starts with your business, not a job description.", "Leadership hiring")}
<section class="sec"><div class="wrap split">
  <div class="rv"><h2>When founders call us</h2><ul class="checks">
    <li>You're hiring your first professional CEO, COO, CFO or CHRO</li><li>A previous senior hire didn't last</li>
    <li>You need to replace a leader confidentially</li><li>The best candidates are employed and not on job portals</li></ul>
    <p>Before any search, we agree what the new leader will decide, how success will be measured in 12 months and what the role will pay. It's the step most firms skip, and the main reason senior hires fail.</p>
    <a class="btn btn-primary" href="/contact/#brief">Share a role {icon('arrow')}</a></div>
  <div class="rv"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Level</th><th>Typical roles</th><th>Fee model</th></tr></thead><tbody>{rows}</tbody></table></div>
    <p class="small muted mt">Fees are agreed in a written proposal within 24 hours of the briefing. <a href="/how-we-work/#fees">How we charge</a>.</p></div>
</div></section>
<section class="sec alt"><div class="wrap"><div class="head"><span class="kicker">Approaches</span><h2>Three ways we find leaders</h2></div><div class="grid g3">{ap}</div></div></section>
<section class="sec" id="industries"><div class="wrap split mid">
  <div><span class="kicker">Industries</span><h2>Sectors we know well</h2><p>We work mostly with manufacturing-led and services businesses, where judging technical credibility matters as much as leadership.</p></div>
  <div class="chips">{''.join(f'<span>{s}</span>' for s in sectors)}</div>
</div></section>
<section class="sec alt"><div class="wrap"><div class="head"><span class="kicker">Results</span><h2>Recent leadership mandates</h2></div><div class="grid g2">{''.join(case_card(c) for c in cases)}</div></div></section>
{faq(fq)}{ladder()}"""
    page("/leadership-hiring/", "Leadership &amp; CXO Hiring for Growing Businesses | EaseBiz",
         "Partner-led executive search, headhunting and leadership hiring for founder-led businesses in India: CXOs, function heads and confidential roles.",
         body, [("Leadership Hiring", "/leadership-hiring/")], [service_ld("Leadership hiring and executive search", "Partner-led CXO, leadership and confidential hiring for growing businesses.", "/leadership-hiring/"), faq_ld(fq)], forms=False)


def build_hr():
    blocks = [("org-design", "layers", "Organisation design", "Everything runs through the MD; roles overlap; decisions wait.", ["Decision-rights map (who decides, who is consulted)", "Leadership layers and a future org chart", "Role charters for every senior role", "A transition plan, including what to hire"]),
              ("performance", "target", "KRAs, KPIs &amp; performance", "Appraisals feel subjective; increments don't match performance.", ["Balanced Scorecard across four pillars", "4–6 KRAs with SMART KPIs per role", "Appraisal process and review calendar", "Manager training and first-cycle support"]),
              ("policies", "file", "HR policies &amp; handbook", "Rules live in people's heads; similar cases get different answers.", ["Review of current practices", "Practical policy set for your size and sector", "Employee handbook ready to circulate", "Manager briefing for consistent use"]),
              ("hrbp", "handshake", "Outsourced HR partner", "HR is handled by accounts or admin; no one owns people strategy.", ["A named senior HR business partner", "Regular on-site or virtual days", "People plan aligned to the business plan", "Hiring support from our search team"])]
    bl = "".join(f"""<div class="card rv" id="{i}"><div class="ico">{icon(ic)}</div><h3>{t}</h3><p class="muted"><b style="color:var(--ink)">Sound familiar?</b> {sym}</p><ul class="checks mb0">{''.join(f'<li>{x}</li>' for x in d)}</ul></div>""" for i, ic, t, sym, d in blocks)
    cases = [c for c in CASES if c["service"] == "hr-advisory"]
    fq = [("Is HR advisory only for large companies?", "No. It's most useful for growing, founder-led companies whose structure and HR systems haven't kept up with the business."),
          ("How long does an engagement take?", "It depends on scope. Our organisation design and Balanced Scorecard engagements each ran about 24 weeks, including implementation support."),
          ("Can you also hire the leaders for the new structure?", "Yes. Because we design the roles, our leadership hiring team can fill them against the same role charters."),
          ("Are your HR policies legally vetted?", "We draft practical policies aligned with common Indian employment practice and recommend a final review by your legal adviser.")]
    body = f"""{phero([("HR Advisory", "/hr-advisory/")], "HR advisory that fixes the structure before you hire into it.", "Organisation design, KRAs and performance systems, HR policies and an HR partner on retainer, from a team that also hires your leaders.", "HR advisory")}
<section class="sec"><div class="wrap"><div class="grid g2">{bl}</div></div></section>
<section class="sec alt"><div class="wrap"><div class="head"><span class="kicker">Results</span><h2>What this looks like in practice</h2></div><div class="grid g2">{''.join(case_card(c) for c in cases)}</div>
<p class="mt">Read more: <a href="/insights/structure-before-hiring/">When everyone reports to the MD</a> · <a href="/insights/kras-that-work/">KRAs that actually work</a></p></div></section>
<section class="sec"><div class="wrap split mid"><div><h2>Not sure where to start?</h2><p class="lead">Take the free 5-minute HR health check and get a no-obligation report on your people practices.</p></div>
<div><a class="btn btn-primary" href="/hr-health-check/" data-track="health_check_click">Take the HR health check {icon('arrow')}</a></div></div></section>
{faq(fq)}{ladder()}"""
    page("/hr-advisory/", "HR Advisory: Org Design, KRAs, Policies, HRBP | EaseBiz",
         "Organisation design, KRA and performance systems, HR policies and outsourced HR business partner services for founder-led and growing companies.",
         body, [("HR Advisory", "/hr-advisory/")], [service_ld("HR advisory", "Organisation design, performance management, HR policies and outsourced HRBP services.", "/hr-advisory/"), faq_ld(fq)])


def build_scale():
    phases = [("Project leadership", "Before construction", "Project head, plant head designate, finance and HR leads"),
              ("Function heads", "During construction", "Production, maintenance, quality, EHS, supply chain, IT/OT"),
              ("Engineers &amp; managers", "Commissioning", "Shift in-charges, process and maintenance engineers, QA/QC"),
              ("Ramp-up workforce", "Start of production", "Supervisors, technicians and operators, hired in batches")]
    rows = "".join(f"<tr><th scope=row>{a}</th><td>{b}</td><td>{c}</td></tr>" for a, b, c in phases)
    c = next(x for x in CASES if x["service"] == "scale-up-hiring")
    fq = [("When should we start hiring for a new plant?", "Hire the project or plant head before construction starts. They shape layout, vendor and process decisions that are expensive to change later."),
          ("Do you handle both leaders and volume roles?", "Yes. Leaders go through our partner-led search; engineers, supervisors and operators go through a dedicated team, against one shared plan."),
          ("How fast can you fill several roles?", "In one engagement we closed 15+ mid-to-senior roles in two weeks for a company opening new units in Ahmedabad.")]
    body = f"""{phero([("Scale-up Hiring", "/scale-up-hiring/")], "Scale-up hiring for new plants, units and locations.", "One phased plan from plant head to shop floor, timed to your launch date, run by one partner.", "Scale-up &amp; plant hiring")}
<section class="sec"><div class="wrap split">
  <div class="rv"><h2>The most expensive mistake in new-plant hiring</h2>
  <p>Hiring the plant head three months before production. By then, layout, equipment and vendor decisions have been made without the person who will run the plant.</p>
  <p>We plan hiring backwards from your commissioning date, so each layer joins in time to shape the decisions it will own.</p></div>
  <div class="card rv"><span class="pill g">{c['metric']}</span><h3 style="font-family:var(--f-display);font-weight:500;font-size:1.4rem;margin-top:12px">{c['headline']}</h3><p>{c['problem']}</p><p class="mb0">{c['result']}</p></div>
</div></section>
<section class="sec alt"><div class="wrap"><div class="head"><span class="kicker">Phased plan</span><h2>Who to hire, and when</h2></div>
<div class="tbl-wrap rv"><table class="tbl"><thead><tr><th>Phase</th><th>When</th><th>Typical roles</th></tr></thead><tbody>{rows}</tbody></table></div></div></section>
{faq(fq)}{ladder()}"""
    page("/scale-up-hiring/", "Scale-up &amp; New Plant Hiring | EaseBiz",
         "Phased hiring for new plants, units and locations, from plant head to operators, timed to your commissioning date. Leadership and volume hiring in one plan.",
         body, [("Scale-up Hiring", "/scale-up-hiring/")], [service_ld("Scale-up and new plant hiring", "Phased leadership and workforce hiring for new plants and locations.", "/scale-up-hiring/"), faq_ld(fq)])


def build_how():
    steps = [("Listen", "A partner meets the founder and key stakeholders. We learn the business, its culture and what's really driving the hire."),
             ("Define", "We agree, in writing, what the role will decide, how success is measured at 12 months and the compensation range."),
             ("Map &amp; approach", "Confidential research across competitor and adjacent companies, and direct approaches to proven people."),
             ("Assess", "Structured interviews, behavioural assessment and in-depth references. You see a short list, not a pile of CVs."),
             ("Land &amp; follow up", "Offer and negotiation support, onboarding guidance, and check-ins with both sides through the first months.")]
    st = "".join(f'<div class="step rv"><b>{i+1}. {t}</b><p>{d}</p></div>' for i, (t, d) in enumerate(steps))
    fees = [("CXO &amp; business-head searches", "Retained", "A retained fee paid in stages through the search. It funds the research and gives the search the priority a CXO role needs."),
            ("Other leadership hires", "Success fee", "You pay when the candidate you hire joins. Suits function heads, senior managers and specialist roles."),
            ("HR advisory &amp; HR partner", "Monthly retainer", "A fixed monthly fee for an agreed scope, so there are no hourly bills to track.")]
    fe = "".join(f'<div class="card fee rv"><span class="kicker" style="margin:0">{a}</span><div class="model">{b}</div><p>{c}</p></div>' for a, b, c in fees)
    principles = [("One partner, start to finish", "No hand-offs to junior recruiters."), ("Structure before search", "We'll tell you if the role isn't ready to hire."),
                  ("Speed without shortcuts", "First profiles within 2 working days."), ("Confidential by default", "For your business and the candidates.")]
    pr = "".join(f'<div class="rv"><h3>{t}</h3><p>{d}</p></div>' for t, d in principles)
    fq = [("Do you charge an upfront fee for every search?", "Only for retained CXO and business-head searches. Other leadership hires are on a success fee."),
          ("When will we get a proposal?", "Within 24 hours of the briefing call, covering scope, timeline and fees."),
          ("What if we decide not to hire after the briefing?", "That's fine. Sometimes the right advice is to fix the structure first, and we'll say so.")]
    body = f"""{phero([("How We Work", "/how-we-work/")], "How we work, and how we charge.", "A simple, partner-led process and clear fee models, agreed in writing before any work begins.", "How we work")}
<section class="sec"><div class="wrap"><div class="grid g4">{pr}</div></div></section>
<section class="sec ink"><div class="wrap"><div class="head"><span class="kicker">The process</span><h2>Five steps, one partner</h2></div><div class="steps five">{st}</div></div></section>
<section class="sec" id="fees"><div class="wrap"><div class="head"><span class="kicker">Fees</span><h2>How we charge</h2><p class="lead">Three simple models. You'll get a written proposal with exact fees within 24 hours of the briefing.</p></div>
<div class="fees">{fe}</div></div></section>
{faq(fq)}{ladder()}"""
    page("/how-we-work/", "How We Work &amp; How We Charge | EaseBiz",
         "EaseBiz's partner-led hiring process in five steps, and our fee models: retained for CXO searches, success fee for leadership hires, retainer for HR advisory.",
         body, [("How We Work", "/how-we-work/")], [faq_ld(fq)])


def build_results():
    metrics = "".join(f'<div class="rv"><div class="metric">{c["metric"]}</div><p class="small muted">{c["tag"]}</p></div>' for c in CASES[1:4])
    full = "".join(f"""<article class="case-full rv" id="{c['id']}"><div><div class="tag" style="display:flex;gap:8px;flex-wrap:wrap"><span class="pill">{c['tag']}</span><span class="pill g">{c['weeks']} weeks</span></div>
<p class="small muted mt">{c['client'] or c['sector']}</p></div>
<div><h2>{c['headline']}</h2><h4>The situation</h4><p>{c['problem']}</p><h4>What we did</h4><p>{c['action']}</p><h4>Result</h4><p class="mb0"><b style="color:var(--ink)">{c['result']}</b></p></div></article>""" for c in CASES)
    logos = "".join(f'<div data-hide-wrap><img src="{IMG}images/client/client{i}.jpg" alt="Client logo" loading="lazy" data-hide-on-error></div>' for i in range(1, 17))
    quotes = "".join(f'<div class="card rv">{quote_block(q)}</div>' for q in QUOTES if q["type"] == "client")
    body = f"""{phero([("Results", "/results/")], "Results, in our clients' words and numbers.", "Representative engagements across leadership hiring, HR advisory and scale-up hiring. Client names are shared where clients have agreed.", "Results")}
<section class="sec alt"><div class="wrap"><div class="grid g3">{metrics}</div></div></section>
<section class="sec"><div class="wrap">{full}</div></section>
<section class="sec alt" id="clients"><div class="wrap"><div class="head"><span class="kicker">Clients</span><h2>Trusted by {S['stats']['clients']} organisations</h2></div>
<div class="grid g2">{quotes}</div><div class="logos mt">{logos}</div></div></section>
{ladder()}"""
    page("/results/", "Results &amp; Case Studies | EaseBiz",
         "EaseBiz case studies: a COO behind a 15% cost cut, 15+ hires in two weeks, an org redesign linked to ~15% growth, and more.",
         body, [("Results", "/results/")])


def li_link(m):
    return f' · <a href="{m["linkedin"]}" target="_blank" rel="noopener">LinkedIn</a>' if m["linkedin"] else ""


def build_about():
    people = "".join(f"""<article class="person rv" id="{m['name'].lower().replace(' ', '-').replace('ca-', '')}"><div class="ph"><img src="{IMG}{m['photo']}" alt="{m['name']}" data-initials="{initials(m['name'])}" loading="lazy"></div>
<div><h3 style="font-family:var(--f-display);font-weight:500;font-size:1.6rem;margin-bottom:4px">{m['name']}</h3><div class="role">{m['role']} · {m['focus']}</div><p>{m['bio']}</p>
<p class="small muted mb0">Leads: {m['leads']}{li_link(m)}</p></div></article>""" for m in TEAM)
    persons = [{"@type": "Person", "name": m["name"], "jobTitle": f"{m['role']}, {m['focus']}", "worksFor": {"@id": ORG_ID},
                "image": SITE + "/" + m["photo"], **({"sameAs": [m["linkedin"]]} if m["linkedin"] else {})} for m in TEAM]
    body = f"""{phero([("About", "/about/")], "A partner-led firm for businesses in transition.", "EaseBiz helps founder-led and growing companies hire professional leaders and build the structure around them, with roots in advisory work going back to 2002.", "About EaseBiz")}
<section class="sec"><div class="wrap split">
  <div class="rv"><h2>Why we exist</h2><p>Growing companies reach a point where the founder can't hold everything together. That's when they need professional leaders, and a structure those leaders can work in.</p>
  <p>Large search firms are built for large corporates. Generalist recruiters fill vacancies. We sit in between: a small team of partners who understand both the people side and the business side, and who stay accountable from first conversation to long after the hire.</p></div>
  <div class="rv"><table class="facts"><caption class="sr">EaseBiz key facts</caption><tbody>
    <tr><th>Legal name</th><td>{S['legal_name']}</td></tr><tr><th>Focus</th><td>Leadership hiring and HR advisory for founder-led and growing businesses</td></tr>
    <tr><th>Head office</th><td>{S['address']}</td></tr><tr><th>Coverage</th><td>Gujarat and pan-India</td></tr>
    <tr><th>Professional roots</th><td>Since 2002</td></tr><tr><th>Clients</th><td>{S['stats']['clients']} · {S['stats']['retention']} retention</td></tr>
    <tr><th>Speed</th><td>First profiles within 2 working days</td></tr><tr><th>Contact</th><td>{S['phone']} · {S['email']}</td></tr></tbody></table></div>
</div></section>
<section class="sec alt" id="partners"><div class="wrap narrow"><div class="head"><span class="kicker">Partners</span><h2>The people you'll work with</h2></div>{people}</div></section>
<section class="sec"><div class="wrap"><div class="grid g4">
  <div class="rv"><h3>Integrity</h3><p>Discretion and honesty, including telling you when not to hire.</p></div>
  <div class="rv"><h3>Quality over volume</h3><p>We take fewer mandates so each gets a partner's full attention.</p></div>
  <div class="rv"><h3>Long-term</h3><p>Most clients come back. That's how we measure ourselves.</p></div>
  <div class="rv"><h3>Structured judgement</h3><p>Clear criteria and process to reduce bias in big decisions.</p></div>
</div><p class="mt"><a href="/careers/">Careers at EaseBiz →</a></p></div></section>
{ladder()}"""
    page("/about/", "About EaseBiz | Partner-Led Leadership Hiring, Ahmedabad",
         "Meet the four partners behind EaseBiz, a partner-led leadership hiring and HR advisory firm for founder-led businesses, based in Ahmedabad since 2002.",
         body, [("About", "/about/")], [ORG, {"@context": "https://schema.org", "@type": "AboutPage", "url": SITE + "/about/", "mainEntity": {"@id": ORG_ID}, "hasPart": persons}])


def build_gujarat():
    places = [("Ahmedabad &amp; Gandhinagar", "Our home base. Pharma, engineering, services and GIFT City-linked financial firms."),
              ("Vadodara", "Engineering, power equipment, chemicals and petrochemicals, about an hour from our office."),
              ("Surat", "Textiles, diamonds and chemicals; many founder-led firms hiring their first professional leaders."),
              ("Rajkot", "Engineering MSMEs: auto components, castings, forgings, pumps and machine tools.")]
    pl = "".join(f'<div class="card rv"><h3>{a}</h3><p>{b}</p></div>' for a, b in places)
    fq = [("Where is EaseBiz's office?", f"{S['address']}."), ("Do you meet clients across Gujarat in person?", "Yes. Our partners regularly meet founders in Ahmedabad, Vadodara, Surat and Rajkot."),
          ("Can you attract leaders from Mumbai or Bengaluru to Gujarat?", "Yes. We map talent nationally and deal with relocation and compensation early in the process.")]
    body = f"""{phero([("Gujarat", "/gujarat/")], "Leadership hiring and HR advisory in Gujarat.", "Headquartered in Prahladnagar, Ahmedabad, we work with Gujarat's founder-led manufacturers and growing businesses across the state.", "Gujarat")}
<section class="sec"><div class="wrap split"><div class="rv"><h2>Why Gujarat businesses work with us</h2>
<p>Much of Gujarat's economy runs on founder- and family-led businesses that are now professionalising: hiring a first COO, CFO or CHRO, or moving beyond an MD-centric structure. That transition needs someone who understands the family dynamics as well as the role.</p>
<p>Strong candidates for these roles often live in Mumbai, Pune or Bengaluru, so a good Gujarat search maps talent nationally and handles relocation questions from the first conversation.</p></div>
<div class="rv card" style="background:var(--bg-2);border:0"><h3>Visit us</h3><p>{S['address']}<br>{S['hours']}</p><p class="mb0"><a href="https://www.google.com/maps/search/?api=1&query=Safal+Pegasus+Prahladnagar+Ahmedabad" target="_blank" rel="noopener">Open in Google Maps ↗</a></p></div></div></section>
<section class="sec alt"><div class="wrap"><div class="head"><h2>Across the state</h2></div><div class="grid g4">{pl}</div></div></section>
{faq(fq)}{ladder()}"""
    page("/gujarat/", "Leadership Hiring &amp; HR Advisory in Gujarat | EaseBiz",
         "Ahmedabad-based leadership hiring and HR advisory for Gujarat's founder-led manufacturers and growing businesses in Vadodara, Surat, Rajkot and beyond.",
         body, [("Gujarat", "/gujarat/")], [ORG, faq_ld(fq)])


def build_india():
    cities = [("Mumbai", "Headquarters roles in BFSI, FMCG and pharma, and Mumbai companies expanding into Gujarat."),
              ("Pune", "Plant and engineering leaders for the auto and capital-goods belt; technology leaders for GCCs."),
              ("Hyderabad", "Quality, regulatory and plant leaders for pharma and life sciences."),
              ("Bengaluru", "Technology leaders, often hired into growing businesses outside Bengaluru."),
              ("Chennai", "Automotive and electronics manufacturing leadership.")]
    ci = "".join(f'<div class="card rv"><h3>{a}</h3><p>{b}</p></div>' for a, b in cities)
    body = f"""{phero([("Pan-India", "/pan-india/")], "Leadership hiring across India, led from Ahmedabad.", "One office, four partners and national talent mapping. We hire wherever the role is, and wherever the best candidate lives.", "Pan-India")}
<section class="sec"><div class="wrap"><p class="lead rv">We don't run branch offices. Every mandate is led by a partner from Ahmedabad, with in-person meetings wherever the search needs them. Candidates are mapped across India, not just in the client's city.</p>
<div class="grid g3 mt">{ci}<div class="card rv" style="background:var(--bg-2);border:0"><h3>And Gujarat</h3><p>Our home market.</p><a class="more" href="/gujarat/">Gujarat {icon('arrow')}</a></div></div></div></section>
{ladder()}"""
    page("/pan-india/", "Leadership Hiring Across India | EaseBiz",
         "EaseBiz runs partner-led leadership hiring from Ahmedabad for companies in Mumbai, Pune, Hyderabad, Bengaluru, Chennai and across India.",
         body, [("Pan-India", "/pan-india/")])


# ---------- Markdown (tiny, dependency-free)
def md(text):
    out, lst, tbl = [], None, []
    def inline(s):
        s = esc(s).replace("&quot;", '"').replace("&#x27;", "'")
        s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
        s = re.sub(r"\[(.+?)\]\((.+?)\)", r'<a href="\2">\1</a>', s)
        return s
    def flush():
        nonlocal lst, tbl
        if lst: out.append(f"</{lst}>"); lst = None
        if tbl:
            rows = [r for r in tbl if not re.match(r"^\|[\s\-|]+\|$", r)]
            cells = lambda r: [c.strip() for c in r.strip("|").split("|")]
            h = "".join(f"<th>{inline(c)}</th>" for c in cells(rows[0]))
            b = "".join("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in cells(r)) + "</tr>" for r in rows[1:])
            out.append(f"<table><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table>"); tbl = []
    for line in text.splitlines():
        if line.startswith("|"): tbl.append(line); continue
        m_ul, m_ol = re.match(r"^- (.*)", line), re.match(r"^\d+\. (.*)", line)
        if m_ul or m_ol:
            kind = "ul" if m_ul else "ol"
            if lst != kind: flush(); out.append(f"<{kind}>"); lst = kind
            out.append(f"<li>{inline((m_ul or m_ol).group(1))}</li>"); continue
        flush()
        if line.startswith("## "): out.append(f"<h2>{inline(line[3:])}</h2>")
        elif line.startswith("### "): out.append(f"<h3>{inline(line[4:])}</h3>")
        elif line.strip(): out.append(f"<p>{inline(line)}</p>")
    flush()
    return "\n".join(out)


def load_posts():
    posts = []
    d = os.path.join(ROOT, "content", "insights")
    for f in sorted(os.listdir(d)):
        if not f.endswith(".md"): continue
        raw = open(os.path.join(d, f), encoding="utf-8").read()
        _, fm, body = raw.split("---", 2)
        meta = dict(l.split(": ", 1) for l in fm.strip().splitlines())
        meta["slug"] = f[:-3]; meta["html"] = md(body.strip())
        meta["words"] = len(body.split())
        posts.append(meta)
    return sorted(posts, key=lambda p: p["date"], reverse=True)


def build_insights():
    posts = load_posts()
    cards = "".join(f'<a class="card post-card rv" href="/insights/{p["slug"]}/"><span class="kicker">{p["tags"].split(",")[0]}</span><h3>{esc(p["title"])}</h3><p>{esc(p["description"])}</p><span class="more">Read · {max(1, round(p["words"]/220))} min {icon("arrow")}</span></a>' for p in posts)
    body = f"""{phero([("Insights", "/insights/")], "Insights for founders and HR leaders.", "Practical notes from our work on leadership hiring, organisation design and HR systems in growing businesses.", "Insights")}
<section class="sec"><div class="wrap"><div class="grid g3">{cards}</div></div></section>{ladder()}"""
    page("/insights/", "Insights on Leadership Hiring &amp; HR | EaseBiz",
         "Practical articles for founders and HR leaders on hiring professional leaders, organisation design and KRAs, from the partners at EaseBiz.", body, [("Insights", "/insights/")])
    for p in posts:
        path = f"/insights/{p['slug']}/"
        art = {"@context": "https://schema.org", "@type": "Article", "headline": p["title"], "description": p["description"], "datePublished": p["date"],
               "dateModified": p["date"], "author": {"@type": "Organization", "name": p["author"], "url": SITE + "/about/"}, "publisher": {"@id": ORG_ID}, "mainEntityOfPage": SITE + path}
        others = "".join(f'<li><a href="/insights/{o["slug"]}/">{esc(o["title"])}</a></li>' for o in posts if o is not p)
        d = datetime.date.fromisoformat(p["date"]).strftime("%d %B %Y")
        body = f"""<section class="phero"><div class="wrap"><nav class="crumbs"><a href="/">Home</a> / <a href="/insights/">Insights</a></nav><span class="kicker">{p['tags'].split(',')[0]}</span><h1 style="max-width:24ch">{esc(p['title'])}</h1><p class="lead mb0">{esc(p['description'])}</p></div></section>
<section class="sec"><div class="wrap"><article class="article"><p class="byline">By {p['author']} · {d} · {max(1, round(p['words']/220))} min read</p>{p['html']}
<div class="card mt" style="background:var(--bg-2);border:0"><h3>Talk it through with a partner</h3><p>A 20-minute call is often enough to find the real issue.</p><a class="btn btn-primary" href="{BOOK}" data-book data-track="book_call_click" data-loc="article">Book a call</a></div>
<h3 class="mt">More insights</h3><ul>{others}</ul></article></div></section>"""
        page(path, esc(p['title']) + (" | EaseBiz" if len(p['title']) <= 50 else ""), p["description"], body, [("Insights", "/insights/"), (p["title"], path)], [art], og_type="article")


def build_checklist():
    items = [("Write down what the new leader will decide alone", "and what stays with the founder or family. A short list means you're hiring a manager, not a leader."),
             ("Define 3–4 measurable outcomes for month 12", "such as 'MIS closed by the 7th' or 'inventory days from 90 to 60'."),
             ("Check the structure is ready", "Who will report to this person? Which decisions move to them on day one?"),
             ("Decide if this is the right first hire", "Sometimes a CHRO or finance controller has to come before the COO or CFO."),
             ("Benchmark compensation before you start", "Leaders who've done this before are well paid where they are."),
             ("Agree a performance component", "tied to the 12-month outcomes, not just a fixed salary."),
             ("Brief long-serving managers early", "Surprises are a top reason new leaders face resistance."),
             ("Agree who meets candidates and in what order", "Founder, family members, key managers. Keep it to three or four interviews."),
             ("Assess judgement and temperament, not just CVs", "Ask how they handled a founder who disagreed with them."),
             ("Take references from people who worked for them", "not only from their bosses."),
             ("Plan the first 90 days before the offer", "including introductions, early wins and a monthly check-in with the founder."),
             ("Decide what you'll do if it isn't working at month 6", "An honest review point protects both sides.")]
    li = "".join(f"<li><b>{a}</b> {b}</li>" for a, b in items)
    body = f"""{phero([("Resources", "/resources/cxo-hiring-checklist/"), ("CXO Hiring Checklist", "/resources/cxo-hiring-checklist/")], "The CXO Hiring Checklist for founder-led businesses.", "12 decisions to make before you start a senior search. Free, takes 10 minutes, and can save you a failed hire.", "Free resource")}
<section class="sec"><div class="wrap split">
  <div><h2>What's inside</h2><ul class="checks"><li>The authority question most founders skip</li><li>How to set 12-month success measures</li><li>Who should interview, and in what order</li><li>A 90-day landing plan</li></ul>
  <p class="muted small">From our guide <a href="/insights/hiring-first-professional-cxo/">Hiring your first professional CXO</a>.</p></div>
  <div class="fcard" data-gate-form="checklist"><h3>Get the checklist</h3>
    <form class="form" data-form="checklist" data-unlock="checklist" data-success="Done. The checklist is open below, and we've noted your email.">
      <div class="two"><div><label for="cl-name">Name</label><input id="cl-name" name="name" required autocomplete="name"></div><div><label for="cl-co">Company</label><input id="cl-co" name="company" autocomplete="organization"></div></div>
      <div><label for="cl-email">Work email</label><input id="cl-email" name="email" type="email" required autocomplete="email"></div>
      <input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">{ts_widget()}
      <button class="btn btn-primary" type="submit">Show me the checklist</button><p class="status" role="status"></p>
      <p class="note">We'll send occasional insights. Unsubscribe anytime. <a href="/privacy/">Privacy</a>.</p></form></div>
</div></section>
<section class="sec alt gated" data-gate="checklist" hidden id="checklist"><div class="wrap narrow"><h2>The checklist</h2><ol class="cl">{li}</ol>
<p class="mt">Want a partner to pressure-test your plan? <a href="{BOOK}" data-book>Book a 20-minute call</a>.</p></div></section>"""
    page("/resources/cxo-hiring-checklist/", "CXO Hiring Checklist for Founder-Led Businesses | EaseBiz",
         "Free checklist: 12 decisions to make before hiring your first professional CEO, COO, CFO or CHRO in a founder-led or family business.",
         body, [("Resources", "/resources/cxo-hiring-checklist/"), ("CXO Hiring Checklist", "/resources/cxo-hiring-checklist/")], forms=True)


def build_health():
    body = f"""{phero([("HR Health Check", "/hr-health-check/")], "Free HR health check.", "Answer a short survey on your HR policies and practices and get a no-obligation report on how to improve productivity. About 5 minutes.", "Free tool")}
<section class="sec"><div class="wrap split">
  <div><h2>What it covers</h2><ul class="checks"><li>Mission, vision and values</li><li>Roles and reporting lines</li><li>KRAs and goal-setting</li><li>Policies and handbook</li><li>Motivation and recognition</li><li>Time management and culture</li></ul>
  <p class="muted">Built by our HR team, who bring 22+ years of experience across industries.</p></div>
  <div class="fcard" id="survey"><h3>Start the survey</h3>
    <!-- DEV: embed the existing 3-step HR score survey here (or point it at the ERP). -->
    <p class="muted">The survey form will be embedded here.</p>
    <a class="btn btn-primary" href="https://www.ease.biz/check-your-hr-score.html" target="_blank" rel="noopener">Open the survey ↗</a></div>
</div></section>{ladder()}"""
    page("/hr-health-check/", "Free HR Health Check | EaseBiz",
         "Take EaseBiz's free 5-minute HR health check covering structure, KRAs, policies and culture, and get a no-obligation improvement report.",
         body, [("HR Health Check", "/hr-health-check/")])


def build_careers():
    ph = "".join(f'<div class="face" data-hide-wrap style="aspect-ratio:1"><img src="{IMG}images/gallery/lifeat/{i}.jpg" alt="Life at EaseBiz" loading="lazy" data-hide-on-error></div>' for i in range(1, 7))
    body = f"""{phero([("Careers", "/careers/")], "Work at EaseBiz.", "A small, consulting-led team where you'll sit in real client conversations and learn from partners directly.", "Careers")}
<section class="sec"><div class="wrap split">
  <div><h2>What it's like</h2><ul class="checks"><li>Senior involvement in meaningful work</li><li>Strategic-level client conversations from early on</li><li>Exposure across hiring, HR advisory and finance</li><li>Clear expectations, real autonomy</li></ul>
  <p>Interested? Email your CV to <a href="mailto:{S['email']}?subject=Careers%20at%20EaseBiz">{S['email']}</a> with "Careers" in the subject.</p>
  <p class="muted small">Looking for roles with our clients instead? <a href="{S['jobs_url']}">See current openings ↗</a></p></div>
  <div class="grid g3" style="gap:10px">{ph}</div>
</div></section>"""
    page("/careers/", "Careers at EaseBiz | Join Our Team in Ahmedabad",
         "Join EaseBiz in Ahmedabad: a consulting-led team working on leadership hiring and HR advisory, with partner mentoring and real client exposure.",
         body, [("Careers", "/careers/")])


def build_contact():
    callf = f"""<form class="form" data-form="call" data-success="Thank you. A partner will email you within one business day to confirm a time.">
      <div class="two"><div><label for="c1-name">Name</label><input id="c1-name" name="name" required autocomplete="name"></div><div><label for="c1-co">Company</label><input id="c1-co" name="company" required autocomplete="organization"></div></div>
      <div class="two"><div><label for="c1-email">Work email</label><input id="c1-email" name="email" type="email" required autocomplete="email"></div><div><label for="c1-phone">Phone</label><input id="c1-phone" name="phone" type="tel" required autocomplete="tel"></div></div>
      <div><label for="c1-time">Preferred time</label><select id="c1-time" name="preferred_time"><option>Morning (10–1)</option><option>Afternoon (2–5)</option><option>Evening (5–7)</option></select></div>
      <div><label for="c1-topic">What would you like to discuss?</label><select id="c1-topic" name="topic"><option>A leadership hire</option><option>HR advisory / structure</option><option>New plant or unit hiring</option><option>Something else</option></select></div>
      <input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">{ts_widget()}
      <button class="btn btn-primary" type="submit">Request a call</button><p class="status" role="status"></p></form>"""
    cbf = f"""<form class="form" data-form="callback" data-success="Thank you. A partner will call you within one business day.">
      <div class="two"><div><label for="c2-name">Name</label><input id="c2-name" name="name" required autocomplete="name"></div><div><label for="c2-phone">Phone</label><input id="c2-phone" name="phone" type="tel" required autocomplete="tel"></div></div>
      <input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">{ts_widget()}
      <button class="btn btn-primary" type="submit">Call me back</button><p class="status" role="status"></p></form>"""
    brief = f"""<form class="form" data-form="brief" data-success="Thank you. You'll receive a written proposal within 24 hours of our briefing call.">
      <div class="two"><div><label for="c3-name">Name</label><input id="c3-name" name="name" required autocomplete="name"></div><div><label for="c3-co">Company</label><input id="c3-co" name="company" required autocomplete="organization"></div></div>
      <div class="two"><div><label for="c3-email">Work email</label><input id="c3-email" name="email" type="email" required autocomplete="email"></div><div><label for="c3-phone">Phone</label><input id="c3-phone" name="phone" type="tel" required autocomplete="tel"></div></div>
      <div class="two"><div><label for="c3-role">Role</label><input id="c3-role" name="role" placeholder="e.g. Chief Operating Officer"></div><div><label for="c3-loc">Location</label><input id="c3-loc" name="location" placeholder="e.g. Ahmedabad"></div></div>
      <div><label for="c3-msg">Context</label><textarea id="c3-msg" name="message" placeholder="Why now, team size, timeline, anything confidential we should know"></textarea></div>
      <input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">{ts_widget()}
      <button class="btn btn-primary" type="submit">Send the brief</button><p class="status" role="status"></p>
      <p class="note">Strictly confidential. <a href="/privacy/">Privacy</a>.</p></form>"""
    book_btn = (f'<p><a class="btn btn-primary" href="{S["booking_url"]}" target="_blank" rel="noopener" data-track="book_call_click" data-loc="contact">Pick a time on our calendar ↗</a></p><p class="muted small">Prefer we arrange it? Use the form below.</p>' if S["booking_url"] else "")
    body = f"""{phero([("Contact", "/contact/")], "Talk to a partner.", "Choose what suits you: book a call, ask for a call back, or send us a role brief. You'll hear from a partner within one business day.", "Contact")}
<section class="sec"><div class="wrap split">
  <div class="fcard">
    <div class="tabs" role="tablist"><button type="button" role="tab" data-tab="call" aria-selected="true">Book a call</button><button type="button" role="tab" data-tab="callback" aria-selected="false">Call me back</button><button type="button" role="tab" data-tab="brief" aria-selected="false">Share a role</button></div>
    <div id="call">{book_btn}{callf}</div><div id="callback" hidden>{cbf}</div><div id="brief" hidden>{brief}</div>
  </div>
  <div>
    <h2>Or reach us directly</h2>
    <ul class="checks"><li><a href="tel:{S['phone_tel']}">{S['phone']}</a> (call or <a href="https://wa.me/{S['whatsapp']}" target="_blank" rel="noopener">WhatsApp</a>)</li><li><a href="mailto:{S['email']}">{S['email']}</a></li><li>{S['address']}</li><li>{S['hours']}</li></ul>
    <p><a href="https://www.google.com/maps/search/?api=1&query=Safal+Pegasus+Prahladnagar+Ahmedabad" target="_blank" rel="noopener">Open in Google Maps ↗</a></p>
    <div class="card mt" style="background:var(--bg-2);border:0"><h3>Looking for a job?</h3><p class="mb0">Candidates, please see <a href="{S['jobs_url']}">current openings</a> or email your CV. This page is for companies hiring.</p></div>
  </div>
</div></section>"""
    page("/contact/", "Contact EaseBiz | Book a Call with a Partner",
         "Book a 20-minute call, request a call back or share a role brief with an EaseBiz partner. Ahmedabad office, +91 81411 65000, grow@ease.biz.",
         body, [("Contact", "/contact/")], [ORG], forms=True)


def build_privacy():
    body = f"""{phero([("Privacy", "/privacy/")], "Privacy policy", "Last updated: 29 October 2026", "")}
<section class="sec"><div class="wrap article">
<p>{S['legal_name']} ("EaseBiz") respects your privacy. This policy explains what personal data we collect through ease.biz and jobs.ease.biz, why, and your rights under India's Digital Personal Data Protection Act, 2023.</p>
<h2>What we collect</h2><ul><li>Details you submit in forms: name, company, email, phone, role details and messages.</li><li>Candidate details: CV, work history, compensation and notice period (on jobs.ease.biz).</li><li>Analytics data, only if you accept analytics cookies: pages visited, device and approximate location.</li><li>Security signals from Cloudflare Turnstile to block spam.</li></ul>
<h2>Why we use it</h2><ul><li>To respond to enquiries and deliver our services.</li><li>To consider candidates for roles, and share a profile with a client only with the candidate's knowledge.</li><li>To send occasional insights if you request a resource (you can unsubscribe anytime).</li><li>To improve the website.</li></ul>
<h2>Retention</h2><p>Enquiry data is kept for up to 3 years after our last contact. Candidate data is kept for up to 3 years unless you ask us to delete it sooner. <!-- EaseBiz: confirm retention periods --></p>
<h2>Sharing</h2><p>We don't sell personal data. We use service providers (hosting, email, our ERP) under confidentiality obligations, and share data where the law requires it.</p>
<h2>Cookies</h2><p>Essential cookies only, unless you accept analytics. You can change your choice by clearing this site's data in your browser.</p>
<h2>Your rights</h2><p>You can ask to access, correct or erase your data, withdraw consent or raise a grievance by writing to <a href="mailto:{S['email']}">{S['email']}</a>. <!-- EaseBiz: name a Grievance Officer if required --></p>
<h2>Contact</h2><p>{S['legal_name']}, {S['address']}. {S['phone']}.</p></div></section>"""
    page("/privacy/", "Privacy Policy | EaseBiz", "How EaseBiz collects, uses and protects personal data from clients, candidates and website visitors under India's DPDP Act, 2023.", body, [("Privacy", "/privacy/")])


def build_404():
    body = f"""<section class="sec"><div class="wrap narrow center"><span class="kicker">404</span><h1>That page has moved.</h1>
<p class="lead">We've redesigned our website. Try one of these:</p>
<div class="row-btns" style="justify-content:center"><a class="btn btn-primary" href="/">Home</a><a class="btn btn-line" href="/leadership-hiring/">Leadership hiring</a><a class="btn btn-line" href="/contact/">Contact</a><a class="btn btn-line" href="{S['jobs_url']}">Jobs ↗</a></div></div></section>"""
    PAGES.append(("/404.html", head("Page not found | EaseBiz", "Page not found", "/404.html") + header("/404") + body + footer()))


# ============================================================ write
REDIRECTS = """# Old site URLs -> new pages (301 keeps Google rankings)
/about-us.html                            /about/                        301
/our-leadership.html                      /about/#partners               301
/life-at-easebiz.html                     /careers/                      301
/gallery.html                             /careers/                      301
/for-candidates.html                      https://jobs.ease.biz/         301
/job-search2.php                          https://jobs.ease.biz/         301
/job-search.php                           https://jobs.ease.biz/         301
/hire-talent.html                         /contact/#brief                301
/our-process.html                         /how-we-work/                  301
/our-services.html                        /                              301
/industries.html                          /leadership-hiring/#industries 301
/case-studies.html                        /results/                      301
/testimonials.html                        /results/#clients              301
/our-clients.html                         /results/#clients              301
/check-your-hr-score.html                 /hr-health-check/              301
/contact-us.html                          /contact/                      301
/privacy-policy.html                      /privacy/                      301
/executive-search-cxo-hiring.html         /leadership-hiring/#search     301
/headhunting-for-niche-roles.html         /leadership-hiring/#headhunting 301
/leadership-and-lateral-hiring.html       /leadership-hiring/#lateral    301
/specialist-domain-focused-hiring.html    /leadership-hiring/#industries 301
/bulk-and-expansion-hiring.html           /scale-up-hiring/              301
"""

HEADERS_PROD = """/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=()
/css/*
  Cache-Control: public, max-age=31536000, immutable
/js/*
  Cache-Control: public, max-age=31536000, immutable
"""


def write():
    out = os.path.join(ROOT, "public")
    if os.path.exists(out): shutil.rmtree(out)
    shutil.copytree(os.path.join(ROOT, "static"), out)
    for path, doc in PAGES:
        fp = os.path.join(out, path.strip("/"), "index.html") if path.endswith("/") else os.path.join(out, path.strip("/"))
        os.makedirs(os.path.dirname(fp), exist_ok=True)
        open(fp, "w", encoding="utf-8").write(doc)
    open(os.path.join(out, "_redirects"), "w").write(REDIRECTS)
    if STAGING:
        open(os.path.join(out, "_headers"), "w").write("/*\n  X-Robots-Tag: noindex, nofollow\n" + HEADERS_PROD.split("\n", 1)[1])
        open(os.path.join(out, "robots.txt"), "w").write("User-agent: *\nDisallow: /\n")
    else:
        open(os.path.join(out, "_headers"), "w").write(HEADERS_PROD)
        open(os.path.join(out, "robots.txt"), "w").write(f"User-agent: *\nAllow: /\n\nSitemap: {SITE}/sitemap.xml\n")
        urls = "".join(f"  <url><loc>{SITE}{p}</loc><lastmod>{TODAY}</lastmod></url>\n" for p in SITEMAP)
        open(os.path.join(out, "sitemap.xml"), "w").write(f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n{urls}</urlset>\n')
    posts = load_posts()
    llms = [f"# {S['legal_name']}", "", "> Partner-led leadership hiring and HR advisory firm for founder-led and growing businesses in India. Headquartered in Ahmedabad, Gujarat. Professional roots since 2002. 750+ clients, 85% client retention. First candidate profiles within 2 working days.", "",
            f"- Office: {S['address']} (single office; serves clients across India)", f"- Contact: {S['phone']} · {S['email']}",
            "- Partners: " + "; ".join(f"{m['name']} ({m['role']}, {m['focus']})" for m in TEAM), "- Fees: retained for CXO searches; success fee for other leadership hires; monthly retainer for HR advisory; written proposal within 24 hours of briefing", "",
            "## Services", f"- [Leadership hiring]({SITE}/leadership-hiring/): CXO, function-head and confidential hiring via executive search and headhunting",
            f"- [HR advisory]({SITE}/hr-advisory/): organisation design, KRAs/KPIs, HR policies, outsourced HR business partner",
            f"- [Scale-up hiring]({SITE}/scale-up-hiring/): phased hiring for new plants and locations", f"- [How we work and fees]({SITE}/how-we-work/)", "",
            "## Proof", f"- [Results]({SITE}/results/): " + "; ".join(f"{c['headline']} ({c['metric']})" for c in CASES), "",
            "## Insights"] + [f"- [{p['title']}]({SITE}/insights/{p['slug']}/)" for p in posts] + ["", "## Other", f"- [About and partners]({SITE}/about/)", f"- [Gujarat]({SITE}/gujarat/)", f"- [Pan-India]({SITE}/pan-india/)", f"- [Job openings]({S['jobs_url']}/)", ""]
    open(os.path.join(out, "llms.txt"), "w", encoding="utf-8").write("\n".join(llms))
    print(f"[{ENV}] {len(PAGES)} pages -> {out}")


for fn in [build_home, build_leadership, build_hr, build_scale, build_how, build_results, build_about, build_gujarat, build_india,
           build_insights, build_checklist, build_health, build_careers, build_contact, build_privacy, build_404]:
    fn()
write()
