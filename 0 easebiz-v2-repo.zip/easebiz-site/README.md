# EaseBiz website v2

A focused, partner-led website for **leadership hiring and HR advisory for founder-led and growing businesses**, built on **Cloudflare Pages + Git**.

```
easebiz-site/
├── build.py              ← generates the site (pure Python, no installs)
├── icons.py
├── content/              ← ✏️ what your team edits
│   ├── settings.json     ← phone, booking link, GA4, Clarity, Turnstile key
│   ├── team.json         ← partners (add LinkedIn URLs here)
│   ├── testimonials.json ← named client quotes
│   ├── cases.json        ← case studies (add "client" when a client agrees to be named)
│   └── insights/*.md     ← articles: add a .md file and it becomes a page
├── static/               ← CSS, JS, images (copy images/ from the old server)
├── functions/api/lead.js ← form handler (Turnstile → ERP webhook and/or email)
├── jobs-site/            ← separate Cloudflare project for jobs.ease.biz
└── public/               ← build output (don't edit; it's regenerated)
```

## Pages (19)
`/` · `/leadership-hiring/` · `/hr-advisory/` · `/scale-up-hiring/` · `/how-we-work/` (includes fees) · `/results/` · `/about/` · `/gujarat/` · `/pan-india/` · `/insights/` plus 3 articles · `/resources/cxo-hiring-checklist/` (lead magnet) · `/hr-health-check/` · `/careers/` · `/contact/` (book a call / call back / role brief) · `/privacy/` · `404`

Every old URL redirects to its new page with a **301** (`_redirects`), so existing Google rankings carry over. `job-search2.php` and `for-candidates.html` go to **jobs.ease.biz**.

---

## 1. Put it on GitHub (one-time)
1. Create a private GitHub repo, e.g. `easebiz-site`.
2. Upload the contents of this folder, or `git init && git add . && git commit -m "v2" && git push`.
3. Add `public/` to `.gitignore` (already included).

## 2. Create the Cloudflare Pages projects

**A. Test site (easebizhr.in)**
1. Cloudflare dashboard → **Workers & Pages → Create → Pages → Connect to Git** → pick the repo.
2. Build command: `python3 build.py`
3. Build output directory: `public`
4. Environment variables:
   - `EB_ENV` = `staging` (noindex, test bar, images from ease.biz)
   - `PYTHON_VERSION` = `3.12`
5. Deploy → **Custom domains** → add `easebizhr.in`.

**B. Production (www.ease.biz)**, after you approve the test site
- Same repo, a second Pages project, with `EB_ENV` = `prod`.
- Copy the old `images/` folder into `static/images/` first.
- Add the custom domains `www.ease.biz` and `ease.biz` (Cloudflare redirects the bare domain to www).

**C. Jobs (jobs.ease.biz)**
- Third Pages project, same repo, **Root directory = `jobs-site`**, no build command, output directory `static`.
- Custom domain: `jobs.ease.biz`.

Every `git push` now rebuilds and redeploys automatically. Each deployment gets its own preview URL, and you can roll back with one click.

## 3. Environment variables (Pages → Settings → Variables and Secrets)

| Project | Variable | Purpose |
|---|---|---|
| main | `TURNSTILE_SECRET` | Spam check. Test value `1x0000000000000000000000000000000AA` always passes |
| main | `LEAD_WEBHOOK_URL`, `LEAD_WEBHOOK_TOKEN` | Sends every lead as JSON to the ERP / CRM / a Google Apps Script |
| main | `RESEND_API_KEY`, `LEAD_EMAIL_TO`, `LEAD_EMAIL_FROM` | Optional email alerts via Resend (verify the ease.biz domain in Resend first) |
| jobs | `ERP_JOBS_URL`, `ERP_APPLY_URL`, `ERP_ALERT_URL`, `ERP_API_KEY` | ERP connection. Without them, the board shows sample jobs in demo mode |

If no lead destination is set, forms return "success" in **demo mode**, which is fine for the test site. **Set at least one destination before production.**

## 4. Before production: checklist

- [ ] `content/settings.json`: add `booking_url` (Zoho Bookings or Calendly), `ga4_id`, `clarity_id`, and the real `turnstile_sitekey`
- [ ] `content/team.json`: partner LinkedIn URLs
- [ ] `content/testimonials.json`: 3–5 **named** client quotes (name, title, company)
- [ ] `content/cases.json`: client names where clients have agreed
- [ ] `static/images/`: copy from the old server, plus a new `og-image.jpg` (1200×630) and **real partner photos**
- [ ] Review the three articles in `content/insights/` and add a partner's name as author
- [ ] Privacy: confirm retention periods and name a Grievance Officer if required
- [ ] Connect the HR health check survey (`/hr-health-check/`)

## 5. ⚠️ Moving ease.biz DNS to Cloudflare: protect your email
`grow@ease.biz` and the other mailboxes depend on **MX records**. When you add ease.biz to Cloudflare:
1. Before changing nameservers, check Cloudflare has imported **all** existing DNS records: MX, TXT (SPF/DKIM/DMARC), and any `mail`, `webmail` or `cpanel` A records.
2. Set mail-related records to **DNS only** (grey cloud).
3. Switch nameservers at the registrar during a quiet hour, then send and receive a test email.
4. Keep the cPanel hosting active for at least 30 days as a fallback. The old `job-search2.php` stays there until the ERP is live.

## 6. After launch
- Google Search Console: add the property, submit `sitemap.xml`, and watch the old URLs redirect cleanly.
- Google Business Profile: same name, address and phone as the site; ask happy clients for reviews.
- GA4: mark `generate_lead`, `book_call_click`, `whatsapp_click` and `call_click` as key events.

## Local preview
```
python3 build.py staging && cd public && python3 -m http.server 8000
```
To test forms and the jobs API locally, use `npx wrangler pages dev public`.
