---
title: When everyone reports to the MD: fix the structure before you hire
description: A practical look at MD bottlenecks in growing companies, the signs, the cost and how a two-layer leadership structure fixes them.
date: 2026-10-29
author: EaseBiz Partners
tags: Organisation design, HR advisory
---
Many growing Indian businesses share one organisation chart: the Managing Director in the middle, and everyone else reporting to them. It works well at 30 people. At 150, it quietly caps the business.

## The signs

- Decisions wait until the MD is back from a trip.
- Senior hires leave within a year because they never got real authority.
- The MD works long days but has no time for strategy, customers or capital.
- Teams escalate small issues because nobody else is allowed to decide.

## What it costs

The cost doesn't show up as a line item. It shows up as slow decisions, lost senior hires and growth that stalls at whatever one person can personally oversee.

## The fix we used

In one engagement, every senior and operational team member reported directly to the MD. Over 24 weeks we:

1. **Mapped decisions, not just roles:** who decides, who is consulted, who is informed.
2. **Introduced a two-layer leadership hierarchy:** a small set of functional heads reporting to the MD, with teams reporting to them.
3. **Redefined roles and responsibilities** so each head owned outcomes, not just tasks.
4. **Supported the transition** as the MD learned to step back and the new heads learned to step up.

Decision-making sped up, teams became more autonomous, and top-line performance grew by roughly 15%.

## Why this comes before hiring

If you hire a strong function head into a structure where everything still flows through the MD, you'll lose them. Fix the structure first, then hire into it. That's why our [HR advisory](/hr-advisory/) and [leadership hiring](/leadership-hiring/) teams work as one.
