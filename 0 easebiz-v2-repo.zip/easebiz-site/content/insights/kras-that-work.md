---
title: KRAs that actually work: a practical guide for growing companies
description: How to replace subjective appraisals with KRAs, SMART KPIs and a simple Balanced Scorecard that managers will actually use.
date: 2026-10-29
author: EaseBiz Partners
tags: Performance management, HR advisory
---
If your appraisals depend on who the manager likes, your best people will leave first. KRAs (key result areas) and KPIs (key performance indicators) are the usual fix, but most companies set them up in a way nobody uses. Here's what works.

## KRA vs KPI in one line

A **KRA** is the outcome a role owns, for example "customer retention". A **KPI** is how you measure it, for example "renewal rate of at least 90%".

## Start at the top

KRAs should cascade from company goals. We use a simple **Balanced Scorecard** with four pillars, so performance isn't judged on revenue alone:

| Pillar | Example company goal | Example KPI for a plant head |
|---|---|---|
| Financial | Improve margins | Conversion cost per unit |
| Customer | On-time delivery | OTIF % |
| Process | Fewer defects | First-pass yield |
| People | Build capability | Training hours per employee |

## Keep each role to 4–6 KRAs

More than six and nothing is a priority. Each KRA gets one or two SMART KPIs: Specific, Measurable, Achievable, Realistic and Time-bound.

## Review quarterly, not yearly

A once-a-year appraisal turns into an argument about memory. Short quarterly check-ins against the same KPIs make the annual review a formality.

## Train the managers

The system fails if managers can't hold a fair, evidence-based conversation. A half-day of manager training is usually the difference between a scorecard that's used and one that sits in a drawer.

## Our experience

We designed and implemented exactly this kind of Balanced Scorecard for an organisation struggling with undefined KPIs and subjective appraisals. The result was better alignment across teams, clearer tracking and measurable gains in accountability.

Want help setting up KRAs? See our [HR advisory services](/hr-advisory/#performance) or take the free [HR health check](/hr-health-check/).
