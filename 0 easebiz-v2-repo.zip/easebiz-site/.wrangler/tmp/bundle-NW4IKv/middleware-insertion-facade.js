				import worker, * as OTHER_EXPORTS from "/home/claude/easebiz2/.wrangler/tmp/pages-m4WxGO/functionsWorker-0.4988339365397978.mjs";
				import * as __MIDDLEWARE_0__ from "/tmp/claude-0/wr/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "/tmp/claude-0/wr/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts";

				export * from "/home/claude/easebiz2/.wrangler/tmp/pages-m4WxGO/functionsWorker-0.4988339365397978.mjs";

				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default
				]
				export default worker;