import { onRequestPost as __api_lead_js_onRequestPost } from "/home/claude/easebiz2/functions/api/lead.js"
import { onRequest as __api_lead_js_onRequest } from "/home/claude/easebiz2/functions/api/lead.js"

export const routes = [
    {
      routePath: "/api/lead",
      mountPath: "/api",
      method: "POST",
      middlewares: [],
      modules: [__api_lead_js_onRequestPost],
    },
  {
      routePath: "/api/lead",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_lead_js_onRequest],
    },
  ]