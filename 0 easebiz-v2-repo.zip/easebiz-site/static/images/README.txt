Copy the current /public_html/images/ folder from the ease.biz cPanel server into this folder before the production launch.
Needed: logo.png, logo-black.png, favicon.png, og-image.jpg (create, 1200x630), the four partner photos
(Ashish-Doshi.JPG, ashish-mehta.jpg, Mitul-Thakkar.jpg, Aesha-Shah.jpg), client/client1-16.jpg, gallery/lifeat/1-6.jpg.
The test build (EB_ENV=staging) loads images straight from www.ease.biz, so it works without this folder.
