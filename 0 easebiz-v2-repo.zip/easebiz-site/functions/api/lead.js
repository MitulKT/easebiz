/**
 * POST /api/lead  (Cloudflare Pages Function)
 * Receives every website form (call, callback, brief, checklist), verifies Cloudflare Turnstile,
 * drops obvious spam, then delivers the lead to one or both of:
 *   - LEAD_WEBHOOK_URL : your ERP / CRM / Google Apps Script endpoint (JSON POST)
 *   - RESEND_API_KEY + LEAD_EMAIL_TO : an email notification via Resend (https://resend.com)
 * Environment variables (Pages → Settings → Variables and Secrets):
 *   TURNSTILE_SECRET   (required in production; test secret 1x0000000000000000000000000000000AA always passes)
 *   LEAD_WEBHOOK_URL   (optional)   LEAD_WEBHOOK_TOKEN (optional, sent as Bearer)
 *   RESEND_API_KEY     (optional)   LEAD_EMAIL_TO e.g. grow@ease.biz   LEAD_EMAIL_FROM e.g. website@ease.biz
 */
const FIELDS = ["form", "page", "name", "company", "email", "phone", "role", "location", "message", "topic", "preferred_time"];
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
const clean = (v) => String(v || "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, 4000);

export async function onRequestPost({ request, env }) {
  let fd;
  try { fd = await request.formData(); } catch { return json({ ok: false, error: "bad_request" }, 400); }

  // Honeypot: real people never fill the hidden "website" field
  if (clean(fd.get("website"))) return json({ ok: true });

  // Turnstile
  const token = fd.get("cf-turnstile-response");
  if (env.TURNSTILE_SECRET) {
    const v = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: new URLSearchParams({ secret: env.TURNSTILE_SECRET, response: token || "", remoteip: request.headers.get("CF-Connecting-IP") || "" }),
    }).then((r) => r.json()).catch(() => ({ success: false }));
    if (!v.success) return json({ ok: false, error: "captcha" }, 400);
  }

  const lead = Object.fromEntries(FIELDS.map((k) => [k, clean(fd.get(k))]));
  if (!lead.name || (!lead.email && !lead.phone)) return json({ ok: false, error: "missing_fields" }, 400);
  if (lead.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(lead.email)) return json({ ok: false, error: "email" }, 400);
  lead.received_at = new Date().toISOString();
  lead.source = "ease.biz";
  lead.country = request.headers.get("CF-IPCountry") || "";

  const jobs = [];
  if (env.LEAD_WEBHOOK_URL) {
    jobs.push(fetch(env.LEAD_WEBHOOK_URL, {
      method: "POST",
      headers: { "content-type": "application/json", ...(env.LEAD_WEBHOOK_TOKEN ? { authorization: `Bearer ${env.LEAD_WEBHOOK_TOKEN}` } : {}) },
      body: JSON.stringify(lead),
    }));
  }
  if (env.RESEND_API_KEY && env.LEAD_EMAIL_TO) {
    const rows = Object.entries(lead).filter(([, v]) => v).map(([k, v]) => `<tr><td style="padding:4px 12px 4px 0;color:#666">${k}</td><td>${v.replace(/</g, "&lt;")}</td></tr>`).join("");
    jobs.push(fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({
        from: env.LEAD_EMAIL_FROM || "EaseBiz Website <website@ease.biz>",
        to: env.LEAD_EMAIL_TO.split(","),
        reply_to: lead.email || undefined,
        subject: `New ${lead.form} lead: ${lead.name}${lead.company ? " (" + lead.company + ")" : ""}`,
        html: `<table>${rows}</table>`,
      }),
    }));
  }
  if (!jobs.length) return json({ ok: true, demo: true }); // nothing configured yet (test site)

  const results = await Promise.allSettled(jobs);
  const delivered = results.some((r) => r.status === "fulfilled" && r.value.ok);
  return delivered ? json({ ok: true }) : json({ ok: false, error: "delivery" }, 502);
}

export const onRequest = () => json({ ok: false, error: "method_not_allowed" }, 405);
