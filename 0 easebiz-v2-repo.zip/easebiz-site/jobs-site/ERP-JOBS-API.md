# EaseBiz ERP ↔ Website: Jobs API contract

The website's job board (jobs.ease.biz: `functions/` + `static/js/jobs.js`) is ready to plug into the EaseBiz ERP. Until the ERP is live it reads `data/jobs.json` (sample data, which is labelled "Sample listing" on the page and never sent to Google).

## 1. Configure jobs.ease.biz (Cloudflare Pages → Settings → Variables and Secrets)

| Variable | Example |
|---|---|
| `ERP_JOBS_URL` | `https://erp.ease.biz/api/v1/jobs` (GET) |
| `ERP_APPLY_URL` | `https://erp.ease.biz/api/v1/applications` (POST multipart) |
| `ERP_ALERT_URL` | `https://erp.ease.biz/api/v1/job-alerts` (POST JSON `{email}`), optional |
| `ERP_API_KEY` | Server-side key, sent as `Authorization: Bearer …`. Never exposed to browsers |

The functions in `jobs-site/functions/` cache the feed for 10 minutes and fall back to `static/data/jobs.json` (sample) when the ERP is unreachable. Job pages live at `/job/<id>/`.

## 2. GET `/jobs?status=open`

**Headers:** `Authorization: Bearer <key>`, `Accept: application/json`
**Response 200:**

```json
{
  "sample": false,
  "generated": "2026-11-15T10:30:00+05:30",
  "jobs": [
    {
      "id": "EB-1042",
      "title": "Chief Operating Officer",
      "company": "Industrial automation manufacturer (confidential)",
      "location": "Ahmedabad",
      "state": "Gujarat",
      "function": "Operations",
      "level": "CXO",
      "experience": "18-25 years",
      "ctc": "Confidential",
      "type": "Full-time",
      "posted": "2026-10-20",
      "valid_through": "2026-12-20",
      "summary": "One or two sentences.",
      "responsibilities": ["...", "..."],
      "requirements": ["...", "..."]
    }
  ]
}
```

| Field | Required | Notes |
|---|---|---|
| `id` | ✅ | Stable, URL-safe. Used in `/job/<id>/` and `#job-…` |
| `title`, `company`, `summary` | ✅ | Plain text (basic HTML entities are fine). Keep the client confidential via `company` wording |
| `location`, `state` | ✅ | City name exactly as you want it in the filter (e.g. "Bengaluru", not "Bangalore") |
| `function`, `level` | ✅ | Drive the filters. Use a fixed list in the ERP: levels `CXO`, `Senior Leadership`, `Mid-Senior`, `Junior` |
| `experience`, `ctc`, `type` | ✅ | Display strings |
| `posted` | ✅ | `YYYY-MM-DD` |
| `valid_through` | optional | `YYYY-MM-DD`. Defaults to posted + 60 days. **Google requires an expiry for job listings**, so close or expire jobs on time |
| `responsibilities`, `requirements` | ✅ | Arrays of strings |
| `is_sample` | optional | `true` hides a job from Google (useful for test jobs) |

Return only **open** jobs. When a job closes, drop it from the feed. The detail URL then returns 404 with a "This role is no longer open" page, which is what Google expects.

## 3. POST `/applications` (multipart/form-data)

The `/api/apply` function forwards these fields after validating them:

| Field | Type | Notes |
|---|---|---|
| `job_id` | string | Matches `jobs[].id` |
| `name`, `email`, `phone` | string | Validated |
| `current_ctc` | number | ₹ lakh per annum, optional |
| `notice_period` | string | `Immediate`, `30 days`, `60 days` or `90 days` |
| `cv` | file | PDF, DOC or DOCX, at most 5 MB (checked before forwarding) |
| `source` | string | Always `jobs.ease.biz` (lets you track channels) |

**Response:** any `2xx` means success. The candidate sees "Application received". Anything else shows an error asking them to email grow@ease.biz.

## 4. SEO: Google for Jobs

- Each real job gets a server-rendered page at `/job/<id>/` with **JobPosting** structured data (title, description, datePosted, validThrough, hiringOrganization, jobLocation).
- Sample jobs (`"sample": true` or `is_sample`) never output JobPosting data.
- Recommended next steps once live:
  - Add job URLs to the sitemap (generate them from the feed).
  - Ping Google's Indexing API when jobs open or close.
  - Add the job title to the URL slug later if you want (e.g. `/job/eb-1042-coo/`).

## 5. Nice-to-haves for the ERP roadmap

- `GET /jobs/{id}` for a single job, so pages don't depend on the full feed
- A `job_alerts` endpoint for the "Notify me" form (currently demo only)
- Webhook to clear the website cache when a job changes (purge the Cloudflare cache, or wait up to 10 minutes)
- Recruiter name per job, so candidates know who they'll speak to (good for trust)
