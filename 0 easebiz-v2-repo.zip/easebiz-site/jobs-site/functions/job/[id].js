// GET /job/:id/ -> server-rendered job page with JobPosting structured data (Google for Jobs)
import { getFeed, layout, jobLd, esc } from "../_lib.js";
export async function onRequestGet({ env, request, params }) {
  const feed = await getFeed(env, request);
  const id = decodeURIComponent(params.id);
  const j = (feed.jobs || []).find((x) => x.id === id);
  const canonical = new URL(`/job/${encodeURIComponent(id)}/`, request.url).toString();
  if (!j) {
    return new Response(layout({ title: "Role closed | EaseBiz Jobs", desc: "This role is no longer open.", canonical, noindex: true,
      body: `<section class="sec"><div class="wrap narrow"><h1>This role is no longer open.</h1><p><a class="btn btn-primary" href="/">See current openings</a></p></div></section>` }),
      { status: 404, headers: { "content-type": "text/html; charset=utf-8" } });
  }
  const sample = feed.sample || j.is_sample;
  const li = (a) => (a || []).map((x) => `<li>${x}</li>`).join("");
  const body = `<section class="phero"><div class="wrap"><nav class="crumbs"><a href="/">Openings</a> / <span>${esc(j.id)}</span></nav>
${sample ? '<span class="sample">Sample listing</span>' : ""}<h1>${j.title}</h1><p class="lead mb0">${j.company} · ${esc(j.location)}, ${esc(j.state)}</p></div></section>
<section class="sec"><div class="wrap split"><div><div class="jt"><span class="l">${j.level}</span><span>${j.function}</span><span>${esc(j.experience)}</span><span>${esc(j.ctc)}</span></div>
<p class="lead" style="margin-top:20px">${j.summary}</p><h2 style="font-size:1.4rem">What you'll do</h2><ul>${li(j.responsibilities)}</ul><h2 style="font-size:1.4rem">What you'll bring</h2><ul>${li(j.requirements)}</ul></div>
<div class="job-detail"><h3>Interested?</h3><p>Apply in confidence. Your profile is shared with the client only with your knowledge.</p><a class="btn btn-primary" href="/#job-${encodeURIComponent(j.id)}">Apply for this role</a></div></div></section>`;
  const head = sample ? "" : `<script type="application/ld+json">${JSON.stringify(jobLd(j))}</script>`;
  return new Response(layout({ title: `${j.title.replace(/<[^>]+>/g, "")}, ${j.location} | EaseBiz Jobs`, desc: j.summary, canonical, body, head, noindex: !!sample }),
    { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "public, max-age=300" } });
}
