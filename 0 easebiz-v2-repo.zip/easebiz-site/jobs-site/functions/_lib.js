// Shared helpers for jobs.ease.biz Pages Functions
export const MAIN = "https://www.ease.biz";

export async function getFeed(env, request) {
  const cache = caches.default;
  const key = new Request(new URL("/__jobs_cache", request.url).toString());
  if (env.ERP_JOBS_URL) {
    const hit = await cache.match(key);
    if (hit) return hit.json();
    try {
      const r = await fetch(env.ERP_JOBS_URL + (env.ERP_JOBS_URL.includes("?") ? "&" : "?") + "status=open", {
        headers: { accept: "application/json", authorization: `Bearer ${env.ERP_API_KEY || ""}` },
        cf: { cacheTtl: 0 },
      });
      if (r.ok) {
        const data = await r.json();
        if (Array.isArray(data.jobs)) {
          await cache.put(key, new Response(JSON.stringify(data), { headers: { "cache-control": "max-age=600", "content-type": "application/json" } }));
          return data;
        }
      }
    } catch (e) { /* fall through to sample */ }
  }
  const s = await env.ASSETS.fetch(new URL("/data/jobs.json", request.url));
  return s.json();
}

export const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const strip = (s) => String(s ?? "").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&");

export function jobLd(j) {
  return {
    "@context": "https://schema.org", "@type": "JobPosting",
    title: strip(j.title),
    description: `<p>${j.summary}</p><ul>${[...(j.responsibilities || []), ...(j.requirements || [])].map((x) => `<li>${x}</li>`).join("")}</ul>`,
    identifier: { "@type": "PropertyValue", name: "EaseBiz", value: j.id },
    datePosted: j.posted,
    validThrough: j.valid_through || new Date(new Date(j.posted).getTime() + 60 * 864e5).toISOString().slice(0, 10),
    employmentType: "FULL_TIME",
    hiringOrganization: { "@type": "Organization", name: strip(j.company), sameAs: MAIN },
    jobLocation: { "@type": "Place", address: { "@type": "PostalAddress", addressLocality: j.location, addressRegion: j.state, addressCountry: "IN" } },
  };
}

export function layout({ title, desc, canonical, body, head = "", noindex = false }) {
  return `<!doctype html><html lang="en-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${title}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${canonical}">
${noindex ? '<meta name="robots" content="noindex">' : ""}
<link rel="icon" href="${MAIN}/images/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,500&family=Public+Sans:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/css/site.css?v=2"><link rel="stylesheet" href="/css/jobs.css?v=2">${head}</head><body>
<header class="top"><div class="wrap nav"><a class="logo" href="/" aria-label="EaseBiz Jobs"><img src="${MAIN}/images/logo-black.png" alt="EaseBiz" width="146" height="38"><span class="wm" hidden>ease<b>biz</b> jobs</span></a>
<nav aria-label="Main"><ul class="menu" style="visibility:visible;transform:none;position:static;flex-direction:row;padding:0;background:none"><li><a href="/">Openings</a></li><li><a href="${MAIN}/">For employers ↗</a></li></ul></nav></div></header>
<main id="main">${body}</main>
<footer class="foot"><div class="wrap"><div class="fbot" style="margin-top:0;border-top:0"><span>© EaseBiz HR Solutions Pvt. Ltd. · Ahmedabad</span><span><a href="${MAIN}/privacy/">Privacy</a> · <a href="mailto:grow@ease.biz">grow@ease.biz</a></span></div></div></footer>
</body></html>`;
}
