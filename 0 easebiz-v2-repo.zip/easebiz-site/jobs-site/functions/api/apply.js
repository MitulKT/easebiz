// POST /api/apply -> validate, then forward the application + CV to the ERP (ERP_APPLY_URL)
const json = (b, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { "content-type": "application/json" } });
export async function onRequestPost({ env, request }) {
  if (!env.ERP_APPLY_URL) return json({ ok: false, error: "not_configured" }, 503);
  const fd = await request.formData();
  const cv = fd.get("cv");
  if (!(cv instanceof File) || cv.size > 5 * 1024 * 1024 || !/\.(pdf|docx?)$/i.test(cv.name)) return json({ ok: false, error: "cv" }, 400);
  const email = String(fd.get("email") || "");
  if (!fd.get("name") || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ ok: false, error: "fields" }, 400);
  const out = new FormData();
  for (const k of ["job_id", "name", "email", "phone", "current_ctc", "notice_period"]) out.append(k, String(fd.get(k) || "").slice(0, 500));
  out.append("source", "jobs.ease.biz");
  out.append("cv", cv, cv.name);
  const r = await fetch(env.ERP_APPLY_URL, { method: "POST", headers: { authorization: `Bearer ${env.ERP_API_KEY || ""}` }, body: out });
  return r.ok ? json({ ok: true }) : json({ ok: false, error: "erp" }, 502);
}
