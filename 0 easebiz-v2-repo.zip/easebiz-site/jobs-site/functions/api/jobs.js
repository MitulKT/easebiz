// GET /api/jobs -> open jobs from the ERP (cached 10 min) or sample data
import { getFeed } from "../_lib.js";
export async function onRequestGet({ env, request }) {
  const feed = await getFeed(env, request);
  return new Response(JSON.stringify(feed), { headers: { "content-type": "application/json", "cache-control": "public, max-age=300" } });
}
