// POST /api/alert -> job-alert signup forwarded to ERP_ALERT_URL (optional)
export async function onRequestPost({ env, request }) {
  const fd = await request.formData();
  const email = String(fd.get("email") || fd.get("al-email") || "");
  if (env.ERP_ALERT_URL && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    await fetch(env.ERP_ALERT_URL, { method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${env.ERP_API_KEY || ""}` }, body: JSON.stringify({ email, source: "jobs.ease.biz" }) });
  }
  return new Response('{"ok":true}', { headers: { "content-type": "application/json" } });
}
