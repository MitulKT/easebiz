import { onRequestPost as __api_alert_js_onRequestPost } from "/home/claude/easebiz2/jobs-site/functions/api/alert.js"
import { onRequestPost as __api_apply_js_onRequestPost } from "/home/claude/easebiz2/jobs-site/functions/api/apply.js"
import { onRequestGet as __api_jobs_js_onRequestGet } from "/home/claude/easebiz2/jobs-site/functions/api/jobs.js"
import { onRequestGet as __job__id__js_onRequestGet } from "/home/claude/easebiz2/jobs-site/functions/job/[id].js"

export const routes = [
    {
      routePath: "/api/alert",
      mountPath: "/api",
      method: "POST",
      middlewares: [],
      modules: [__api_alert_js_onRequestPost],
    },
  {
      routePath: "/api/apply",
      mountPath: "/api",
      method: "POST",
      middlewares: [],
      modules: [__api_apply_js_onRequestPost],
    },
  {
      routePath: "/api/jobs",
      mountPath: "/api",
      method: "GET",
      middlewares: [],
      modules: [__api_jobs_js_onRequestGet],
    },
  {
      routePath: "/job/:id",
      mountPath: "/job",
      method: "GET",
      middlewares: [],
      modules: [__job__id__js_onRequestGet],
    },
  ]