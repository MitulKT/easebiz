/* EaseBiz job board (client side).
   Data source: window.EB_JOBS_URL (ERP endpoint) or data/jobs.json (sample).
   Apply endpoint: window.EB_APPLY_URL. If not set, the form runs in demo mode.
   Field contract: see ERP-JOBS-API.md. */
(function () {
  "use strict";
  var SRC = window.EB_JOBS_URL || "/api/jobs";
  var APPLY = window.EB_APPLY_URL || "/api/apply";
  var $ = function (s) { return document.querySelector(s); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
  var jobs = [], current = null, isSample = false;

  function ago(d) {
    var days = Math.floor((Date.now() - new Date(d).getTime()) / 864e5);
    return days <= 0 ? "Today" : days === 1 ? "1 day ago" : days < 30 ? days + " days ago" : new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
  }
  function opts(sel, key) {
    var vals = Array.from(new Set(jobs.map(function (j) { return j[key]; }))).sort();
    vals.forEach(function (v) { var o = document.createElement("option"); o.value = v; o.innerHTML = v; sel.appendChild(o); });
  }
  function filtered() {
    var q = ($("#q").value || "").toLowerCase().trim();
    var loc = $("#f-loc").value, fn = $("#f-fn").value, lvl = $("#f-lvl").value;
    return jobs.filter(function (j) {
      if (loc && j.location !== loc) return false;
      if (fn && j.function !== fn) return false;
      if (lvl && j.level !== lvl) return false;
      if (!q) return true;
      return [j.title, j.company, j.summary, j.function, j.location].concat(j.requirements || []).join(" ").toLowerCase().indexOf(q) > -1;
    });
  }
  function card(j) {
    return '<a class="job-card' + (current && current.id === j.id ? " on" : "") + '" href="#job-' + esc(j.id) + '" data-id="' + esc(j.id) + '">' +
      "<h3>" + j.title + '</h3><div class="co">' + j.company + "</div>" +
      '<div class="jt"><span class="l">' + j.level + "</span><span>📍 " + esc(j.location) + "</span><span>" + esc(j.experience) + "</span><span>" + ago(j.posted) + "</span></div></a>";
  }
  function detail(j) {
    var li = function (a) { return (a || []).map(function (x) { return "<li>" + x + "</li>"; }).join(""); };
    return (isSample || j.is_sample ? '<span class="sample">Sample listing</span>' : "") +
      "<h2>" + j.title + '</h2><p class="muted">' + j.company + " · " + esc(j.location) + ", " + esc(j.state) + "</p>" +
      '<div class="jt"><span class="l">' + j.level + "</span><span>" + j.function + "</span><span>" + esc(j.experience) + "</span><span>" + esc(j.ctc) + "</span><span>" + esc(j.type) + "</span></div>" +
      "<p class=\"mt-2\">" + j.summary + "</p>" +
      "<h4>What you'll do</h4><ul>" + li(j.responsibilities) + "</ul>" +
      "<h4>What you'll bring</h4><ul>" + li(j.requirements) + "</ul>" +
      '<div class="btn-row mt-2"><button class="btn btn-primary" type="button" data-apply="' + esc(j.id) + '">Apply now</button>' +
      '<a class="btn btn-line" href="/job/' + encodeURIComponent(j.id) + '/">Full page</a><button class="btn btn-line" type="button" data-share="' + esc(j.id) + '">Copy link</button></div>' +
      '<p class="hint mt-2">Ref: ' + esc(j.id) + " · Posted " + ago(j.posted) + "</p>";
  }
  function schema(j) {
    var old = document.getElementById("jobposting-ld"); if (old) old.remove();
    if (!j || isSample || j.is_sample) return; // never publish structured data for sample jobs
    var s = document.createElement("script"); s.type = "application/ld+json"; s.id = "jobposting-ld";
    var strip = function (t) { var d = document.createElement("div"); d.innerHTML = t; return d.textContent; };
    s.textContent = JSON.stringify({
      "@context": "https://schema.org", "@type": "JobPosting", title: strip(j.title), identifier: { "@type": "PropertyValue", name: "EaseBiz", value: j.id },
      description: "<p>" + j.summary + "</p><ul>" + (j.responsibilities || []).concat(j.requirements || []).map(function (x) { return "<li>" + x + "</li>"; }).join("") + "</ul>",
      datePosted: j.posted, validThrough: j.valid_through || undefined, employmentType: "FULL_TIME",
      hiringOrganization: { "@type": "Organization", name: strip(j.company) },
      jobLocation: { "@type": "Place", address: { "@type": "PostalAddress", addressLocality: j.location, addressRegion: j.state, addressCountry: "IN" } }
    });
    document.head.appendChild(s);
  }
  function render() {
    var list = filtered();
    $("#count").textContent = list.length + (list.length === 1 ? " role" : " roles") + (isSample ? " · sample data" : "");
    $("#list").innerHTML = list.length ? list.map(card).join("") : '<div class="empty">No roles match. Try clearing a filter, or <a href="#alerts">share your profile</a>.</div>';
  }
  function select(id, scroll) {
    var j = jobs.find(function (x) { return x.id === id; }); if (!j) return;
    current = j; render();
    var html = detail(j);
    if (window.matchMedia("(max-width: 960px)").matches) {
      var c = document.querySelector('.job-card[data-id="' + id + '"]');
      if (c) { var d = document.createElement("div"); d.className = "job-detail"; d.style.display = "block"; d.style.position = "static"; d.style.maxHeight = "none"; d.innerHTML = html; c.after(d); if (scroll) c.scrollIntoView({ behavior: "smooth", block: "start" }); }
    } else { $("#detail").innerHTML = html; }
    schema(j);
  }
  function fromHash() { var m = location.hash.match(/^#job-(.+)$/); if (m) select(decodeURIComponent(m[1]), true); }

  // events
  ["#q", "#f-loc", "#f-fn", "#f-lvl"].forEach(function (s) { $(s).addEventListener("input", render); });
  window.addEventListener("hashchange", fromHash);
  document.addEventListener("click", function (e) {
    var a = e.target.closest("[data-apply]"), sh = e.target.closest("[data-share]"), x = e.target.closest(".drawer-x"), dr = e.target === $("#apply");
    if (a) { var j = jobs.find(function (y) { return y.id === a.dataset.apply; }); $("#ap-job").value = j.id; $("#ap-role").innerHTML = j.title + " · " + esc(j.location); $("#ap-msg").textContent = ""; $("#apply").hidden = false; $("#ap-name").focus(); }
    if (sh) { var url = location.href.split("#")[0] + "#job-" + sh.dataset.share; (navigator.clipboard ? navigator.clipboard.writeText(url) : Promise.reject()).then(function () { sh.textContent = "Link copied"; }, function () { prompt("Copy this link", url); }); }
    if (x || dr) $("#apply").hidden = true;
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") $("#apply").hidden = true; });
  $("#apply-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var msg = $("#ap-msg"), f = e.target;
    var cv = $("#ap-cv").files[0];
    if (cv && cv.size > 5 * 1024 * 1024) { msg.textContent = "Your CV is larger than 5 MB. Please upload a smaller file."; return; }
    
    msg.textContent = "Sending…";
    fetch(APPLY, { method: "POST", body: new FormData(f) }).then(function (r) {
      if (r.status === 503) { msg.textContent = "Demo mode: applications will reach the EaseBiz ERP once it is connected."; return "demo"; }
      if (!r.ok) throw new Error(r.status);
      return "ok";
    }).then(function (st) { if (st === "ok") { msg.textContent = "Application received. Our consultant will contact you if your profile matches."; f.reset(); } }).catch(function () { msg.textContent = "Something went wrong. Please try again, or email your CV to grow@ease.biz."; });
  });
  $("#alert-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var fd = new FormData(e.target); fd.append("job_id", "ALERT"); fd.append("name", "Job alert"); fd.append("type", "alert");
    fetch(APPLY.replace("apply", "alert"), { method: "POST", body: fd }).catch(function () {});
    e.target.querySelector("button").textContent = "Subscribed";
  });

  // load
  fetch(SRC, { headers: { Accept: "application/json" } }).then(function (r) { if (!r.ok) throw 0; return r.json(); }).catch(function () { return fetch("/data/jobs.json").then(function (r) { return r.json(); }); }).then(function (data) {
    jobs = (data.jobs || data).sort(function (a, b) { return b.posted.localeCompare(a.posted); });
    isSample = !!data.sample;
    opts($("#f-loc"), "location"); opts($("#f-fn"), "function"); opts($("#f-lvl"), "level");
    var p = new URLSearchParams(location.search);
    if (p.get("location")) $("#f-loc").value = p.get("location");
    if (p.get("q")) $("#q").value = p.get("q");
    render();
    if (location.hash) fromHash(); else if (jobs.length && !window.matchMedia("(max-width: 960px)").matches) select(filtered()[0] ? filtered()[0].id : jobs[0].id);
  }).catch(function () {
    $("#count").textContent = "";
    $("#list").innerHTML = '<div class="empty">We couldn\'t load openings right now. Please email <a href="mailto:grow@ease.biz">grow@ease.biz</a> with your CV.</div>';
  });
})();
