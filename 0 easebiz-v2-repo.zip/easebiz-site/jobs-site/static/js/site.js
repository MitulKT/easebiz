/* EaseBiz v2 site script. No dependencies. */
(function () {
  "use strict";
  var S = window.EB || {};          // settings injected by the page (ga4, clarity, booking)
  document.documentElement.classList.add("js");
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  // ---------- Menu
  var burger = document.querySelector(".burger");
  if (burger) burger.addEventListener("click", function () {
    var o = document.body.classList.toggle("open"); burger.setAttribute("aria-expanded", o);
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") document.body.classList.remove("open"); });

  // ---------- Reveal (content is visible without JS; this only animates)
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
    }, { threshold: 0.12 });
    $$(".rv").forEach(function (el) { io.observe(el); });
    setTimeout(function () { $$(".rv").forEach(function (el) { el.classList.add("in"); }); }, 2500); // safety net
  } else { $$(".rv").forEach(function (el) { el.classList.add("in"); }); }

  // ---------- Image fallbacks
  $$("img[data-initials]").forEach(function (img) {
    function fb() { var d = document.createElement("div"); d.className = "initials"; d.textContent = img.dataset.initials; img.replaceWith(d); }
    if (img.complete && !img.naturalWidth) fb(); else img.addEventListener("error", fb);
  });
  $$("img[data-hide-on-error]").forEach(function (img) {
    function fb() { (img.closest("[data-hide-wrap]") || img).style.display = "none"; }
    if (img.complete && !img.naturalWidth) fb(); else img.addEventListener("error", fb);
  });
  $$(".logo img").forEach(function (img) {
    function fb() { img.hidden = true; var w = img.nextElementSibling; if (w) w.hidden = false; }
    if (img.complete && !img.naturalWidth) fb(); else img.addEventListener("error", fb);
  });

  // ---------- Analytics (only after consent)
  function track(name, params) {
    if (window.gtag) window.gtag("event", name, params || {});
  }
  function loadAnalytics() {
    if (S.ga4) {
      var g = document.createElement("script"); g.async = true; g.src = "https://www.googletagmanager.com/gtag/js?id=" + S.ga4; document.head.appendChild(g);
      window.dataLayer = window.dataLayer || []; window.gtag = function () { window.dataLayer.push(arguments); };
      window.gtag("js", new Date()); window.gtag("config", S.ga4, { anonymize_ip: true });
    }
    if (S.clarity) {
      (function (c, l, a, r, i, t, y) { c[a] = c[a] || function () { (c[a].q = c[a].q || []).push(arguments); };
        t = l.createElement(r); t.async = 1; t.src = "https://www.clarity.ms/tag/" + i; y = l.getElementsByTagName(r)[0]; y.parentNode.insertBefore(t, y);
      })(window, document, "clarity", "script", S.clarity);
    }
  }
  var consent = store.get("eb-consent");
  if (consent === "yes") loadAnalytics();
  else if (consent === null && (S.ga4 || S.clarity)) {
    var bar = document.createElement("div"); bar.className = "consent"; bar.setAttribute("role", "dialog"); bar.setAttribute("aria-label", "Cookie preferences");
    bar.innerHTML = '<p>We use analytics cookies to understand which pages help visitors. No advertising cookies. <a href="/privacy/">Privacy policy</a></p>' +
      '<div class="row-btns"><button class="btn btn-primary" data-c="yes">Accept analytics</button><button class="btn btn-line" data-c="no">Decline</button></div>';
    document.body.appendChild(bar);
    bar.addEventListener("click", function (e) {
      var c = e.target.getAttribute("data-c"); if (!c) return;
      store.set("eb-consent", c); bar.remove(); if (c === "yes") loadAnalytics();
    });
  }
  document.addEventListener("click", function (e) {
    var a = e.target.closest("a, button"); if (!a) return;
    var href = a.getAttribute("href") || "";
    if (a.dataset.track) track(a.dataset.track, { location: a.dataset.loc || location.pathname });
    else if (href.indexOf("wa.me") > -1) track("whatsapp_click", { location: location.pathname });
    else if (href.indexOf("tel:") === 0) track("call_click", { location: location.pathname });
    else if (href.indexOf("mailto:") === 0) track("email_click", { location: location.pathname });
  });

  // ---------- Booking buttons: use the booking link if configured, else go to the call form
  $$("[data-book]").forEach(function (a) {
    if (S.booking) { a.href = S.booking; a.target = "_blank"; a.rel = "noopener"; }
  });

  // ---------- Contact tabs
  $$(".tabs").forEach(function (tabs) {
    var btns = $$("button", tabs);
    function show(id) {
      btns.forEach(function (b) { var on = b.dataset.tab === id; b.setAttribute("aria-selected", on); var p = document.getElementById(b.dataset.tab); if (p) p.hidden = !on; });
    }
    btns.forEach(function (b) { b.addEventListener("click", function () { show(b.dataset.tab); history.replaceState(null, "", "#" + b.dataset.tab); }); });
    var h = location.hash.replace("#", ""); if (h && btns.some(function (b) { return b.dataset.tab === h; })) show(h);
  });

  // ---------- Forms -> /api/lead (Cloudflare Pages Function)
  $$("form[data-form]").forEach(function (f) {
    f.addEventListener("submit", function (e) {
      e.preventDefault();
      var st = f.querySelector(".status"), btn = f.querySelector("[type=submit]");
      var data = new FormData(f); data.append("form", f.dataset.form); data.append("page", location.pathname);
      st.className = "status"; st.textContent = "Sending…"; btn.disabled = true;
      fetch("/api/lead", { method: "POST", body: data }).then(function (r) {
          if (r.status === 404 || r.status === 405) return { ok: true, j: { ok: true, demo: true } }; // functions not deployed (drag-and-drop test upload)
          return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          if (!res.ok || !res.j.ok) throw new Error(res.j && res.j.error);
          st.className = "status ok"; st.textContent = res.j.demo ? "Demo mode: this test site isn't connected to email or the ERP yet." : (f.dataset.success || "Thank you. A partner will get back to you within one business day.");
          track("generate_lead", { form: f.dataset.form }); f.reset();
          if (f.dataset.unlock) { store.set("eb-unlock-" + f.dataset.unlock, "1"); unlock(f.dataset.unlock); }
          if (window.turnstile) try { window.turnstile.reset(); } catch (x) {}
        })
        .catch(function () {
          st.className = "status err";
          st.innerHTML = "That didn't go through. Please try again, or WhatsApp / call us on <a href=\"tel:" + (S.tel || "") + "\">" + (S.phone || "our number") + "</a>.";
        })
        .then(function () { btn.disabled = false; });
    });
  });

  // ---------- Gated content (soft gate, remembered per browser)
  function unlock(id) { $$('[data-gate="' + id + '"]').forEach(function (el) { el.hidden = false; }); $$('[data-gate-form="' + id + '"]').forEach(function (el) { el.hidden = true; }); }
  $$("[data-gate]").forEach(function (el) { if (store.get("eb-unlock-" + el.dataset.gate)) unlock(el.dataset.gate); });

  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
})();
